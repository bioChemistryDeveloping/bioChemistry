Interface interface2;
final class Interface {
  private float distance, scale, plateX, plateY;
  private HashSet<Integer> clicks;
  private final Button compilate, exit;
  private boolean window;
  public EditText source;
  private final int split;
  private int consoleX, consoleY;
  private final PShader splitPolygons;
  private boolean type;
  private String log;
  public final int resolution;
  private byte mode;
  public boolean operation;
  private final Sound switchSound, errorSound;
  private final ArrayList<Button> buttons;
  private final class Button {
    private final float positionX, positionY, resolutionX, resolutionY, textX, textY;
    private final byte red, green, blue;
    private final String name;
    Button(float positionX, float positionY, float resolutionX, float resolutionY, byte red, byte green, byte blue, String name) {
      this.positionX = positionX * resolution;
      this.positionY = positionY * resolution;
      this.resolutionX = (positionX + resolutionX) * resolution;
      this.resolutionY = (positionY + resolutionY) * resolution;
      textX = (this.positionX + this.resolutionX) / 2;
      textY = (this.positionY + this.resolutionY) / 2;
      this.red = red;
      this.green = green;
      this.blue = blue;
      this.name = name;
    }
    public final boolean update(byte number) {
      boolean touching = false;
      for (final TouchEvent.Pointer touch : touches) {
        if (touch.x > positionX && touch.x < resolutionX && touch.y > positionY && touch.y < resolutionY) {
          touching = true;
          break;
        }
      }
      if (touching) {
        if (click) {
          switchSound.play(1);
          click = false;
        }
        fill(255);
      } else if (mode == number) {
        fill(#00A5FF);
      } else {
        fill(0);
      }
      beginShape();
      vertex(positionX, resolutionY);
      fill(red & 0xFF, green & 0xFF, blue & 0xFF);
      vertex(positionX, positionY);
      vertex(resolutionX, positionY);
      fill(40);
      vertex(resolutionX, resolutionY);
      endShape();
      fill(255);
      text(name, textX, textY);
      return touching;
    }
  }
  private final void paint(android.text.Editable text, String pattern, int color) {
    final java.util.regex.Matcher matcher = java.util.regex.Pattern.compile(pattern).matcher(text);
    while (matcher.find()) {
      text.setSpan(new android.text.style.ForegroundColorSpan(color), matcher.start(), matcher.end(), android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }
  }
  Interface() {
    clicks = new HashSet<Integer>();
    resolution = width + height;
    split = int(height / 32);
    consoleY = int(height * 0.8);
    splitPolygons = loadShader("split.fragment", "split.vertex");
    consoleX = width / 2;
    log = "no problems found";
    compilate = new Button(0.032, 0.001, 0.05, 0.03, byte(255), byte(255), byte(0), "compilate");
    exit = new Button(0.001, 0.001, 0.03, 0.03, byte(255), byte(0), byte(0), "X");
    final String[] config = loadStrings("config.txt");
    buttons = new ArrayList<Button>();
    String token = "";
    final ArrayList<String> tokens = new ArrayList<String>();
    for (final String stroke : config) {
      for (final char character : stroke.toCharArray()) {
        if (character == '-') {
          tokens.add(token);
          token = "";
        } else {
          token += character;
        }
      }
      tokens.add(token);
      token = "";
      buttons.add(new Button(float(tokens.get(0)), float(tokens.get(1)), float(tokens.get(2)), float(tokens.get(3)), byte(int(tokens.get(4))), byte(int(tokens.get(5))), byte(int(tokens.get(6))), tokens.get(7)));
      tokens.clear();
    }
    textSize(resolution / 130);
    final Activity constructor = getActivity();
    final java.util.concurrent.CountDownLatch ready = new java.util.concurrent.CountDownLatch(1);
    constructor.runOnUiThread(new Runnable() {
      public final void run() {
        source = new EditText(constructor);
        source.setBackgroundColor(0);
        source.setHintTextColor(#474747);
        source.setHint("write some script...");
        source.setTextColor(#FFFFFF);
        source.setGravity(Gravity.TOP | Gravity.START);
        final int character = resolution / 100;
        source.setTextSize(TypedValue.COMPLEX_UNIT_PX, character);
        constructor.addContentView(source, new FrameLayout.LayoutParams(width, consoleY - split));
        source.setX(character);
        source.setY(character * 4);
        source.setHorizontallyScrolling(true);
        source.setText(join(loadStrings("source.logics"), '\n'));
        source.setVisibility(View.GONE);
        ready.countDown();
        source.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
      }
    });
    try {
      ready.await();
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
    }
    source.addTextChangedListener(new android.text.TextWatcher() {
      public void beforeTextChanged(CharSequence text, int start, int count, int after) {
      }
      public void onTextChanged(CharSequence text, int start, int before, int count) {
      }
      public void afterTextChanged(android.text.Editable text) {
        for (final android.text.style.ForegroundColorSpan span : text.getSpans(0, text.length(), android.text.style.ForegroundColorSpan.class)) {
          text.removeSpan(span);
        }
        paint(text, "\\b(MASS|LINKS)\\b", 0xFF3FFFC8);
        paint(text, "-?\\b\\d+(\\.\\d+)?\\b", 0xFFC8FFFF);
        paint(text, "[{};]", 0xFFC8C8C8);
        paint(text, "\\bheirdom\\b|==|!=|<=|>=|<|>|-|/|\\+|\\*", 0xFF3FFF3F);
        paint(text, "\\b(byte|int|float)\\b", 0xFFFF7F3F);
        paint(text, "\\b(if|load|return)\\b", 0xFFFF3FFF);
        paint(text, "\\b(organelle|diffusion|detect|split|apoptosis|break|red|green|blue)\\b", 0xFF3F7FFF);
        paint(text, "//.*", 0xFF7F7F7F);
      }
    });
    switchSound = new Sound("switch.mp3");
    errorSound = new Sound("error.mp3");
  }
  public final void returns(boolean type, String log) {
    this.log = log;
    this.type = type;
    if (type) {
      errorSound.play(1);
    }
  }
  public final void update() {
    if (window) {
      fill(0, 230);
      rect(0, 0, width, height);
      if (exit.update(byte(0))) {
        getActivity().runOnUiThread(new Runnable() {
          public final void run() {
            source.setVisibility(View.GONE);
          }
        });
        window = false;
        key = '\0';
      } else if (compilate.update(byte(0))) {
        scene.caller.update(byte(6), null);
      }
      final int widget = consoleY - split;
      if (mousePressed && mouseY > widget && mouseY < consoleY) {
        consoleY = mouseY + split / 2;
        fill(64, 127, 255);
        getActivity().runOnUiThread(new Runnable() {
          public final void run() {
            final android.view.ViewGroup.LayoutParams params = source.getLayoutParams();
            params.height = consoleY - split * 3;
            source.setLayoutParams(params);
          }
        });
      } else {
        fill(255);
      }
      shader(splitPolygons);
      beginShape();
      vertex(0, widget, 0, 0);
      vertex(0, height, 1, 0);
      vertex(width, height, 0, 1);
      vertex(width, widget, 1, 1);
      endShape();
      resetShader();
      fill(10);
      beginShape();
      vertex(0, consoleY);
      vertex(0, height);
      vertex(width, height);
      vertex(width, consoleY);
      endShape();
      textAlign(CENTER, BASELINE);
      if (type) {
        fill(255, 0, 0);
      } else {
        fill(255);
      }
      text(log, consoleX, consoleY + split);
    } else {
      boolean instrument = true;
      textAlign(CENTER, CENTER);
      for (byte button = 0; button < buttons.size(); button++) {
        if (buttons.get(button).update(button)) {
          if (button < 4) {
            mode = button;
          } else if (button == 4) {
            window = true;
            getActivity().runOnUiThread(new Runnable() {
              public final void run() {
                source.setVisibility(View.VISIBLE);
              }
            });
          } else {
            switch (button) {
              case 5 : {
                scene.caller.cleanUp();
                break;
              }
              case 6 : {
                scene.caller.zoom(-0.003);
                break;
              }
              case 7 : {
                scene.caller.zoom(0.003);
                break;
              }
              case 8 : {
                scene.caller.zoom(-0.006);
                break;
              }
              case 9 : {
                scene.caller.zoom(0.006);
              }
            }
          }
          instrument = false;
        }
      }
      if (touches.length == 2) {
        final TouchEvent.Pointer touch = touches[0], touch2 = touches[1];
        final float centerX = (touch.x + touch2.x) / 2, centerY = (touch.y + touch2.y) / 2, current = dist(touch.x, touch.y, touch2.x, touch2.y);
        boolean started = false;
        HashSet<Integer> touchesStarted = new HashSet<Integer>();
        for (TouchEvent.Pointer touch3 : touches) {
          touchesStarted.add(touch3.id);
          if (!clicks.contains(touch3.id)) {
            started = true;
          }
        }
        clicks = touchesStarted;
        if (started) {
          distance = current;
          scale = scene.microscopeScale;
          plateX = centerX / scale + scene.microscopeX;
          plateY = centerY / scale + scene.microscopeY;
        }
        final float local = max(scale * current / distance, 10);
        scene.microscopeX = plateX - centerX / local;
        scene.microscopeY = plateY - centerY / local;
        scene.microscopeScale = local;
      } else if (!clicks.isEmpty()) {
        clicks.clear();
        click = true;
      } else {
        if (instrument && operation) {
          for (final TouchEvent.Pointer touch : touches) {
            scene.caller.update(mode, touch);
          }
        }
      }
      if (touches.length > 0 && mode > 1) {
        operation = false;
      } else {
        operation = true;
      }
    }
  }
}