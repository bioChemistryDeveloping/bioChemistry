final class Sound {
  private int file;
  public SoundPool buffer;
  Sound(String name) {
    try {
      buffer = new SoundPool.Builder().setMaxStreams(20).build();
      file = buffer.load(new File(getActivity().getCacheDir(), name).getAbsolutePath(), 1);
    } catch(Exception log) {
      println(log);
    }
  }
  public final void play(float volume) {
    buffer.play(file, volume, volume, 1, 0, random(0.8, 1.2));
  }
}