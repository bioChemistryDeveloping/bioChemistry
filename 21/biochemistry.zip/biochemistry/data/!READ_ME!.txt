версия apde : 0.5.3
gmail разработчика : biochemistrydev@gmail.com
используемое sdk при заработке : 36