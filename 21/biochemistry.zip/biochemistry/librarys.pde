/* activity */ {
  import android.content.Intent;
}
/* Interface */ {
  import java.util.HashSet;
  import android.util.TypedValue;
  import android.view.Gravity;
  import android.app.Activity;
  import android.widget.EditText;
  import android.graphics.Typeface;
  import android.widget.FrameLayout;
  import android.view.View;
  import android.text.*;
  import android.text.style.ForegroundColorSpan;
  import java.util.regex.*;
}
/* Sound */ {
  import java.io.*;
  import android.media.SoundPool;
  import android.media.AudioAttributes;
  import android.content.res.AssetFileDescriptor;
}