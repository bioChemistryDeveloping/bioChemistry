final void setup() {
  fullScreen(P2D);
  debug = new Debug();
  Intent intent = getActivity().getIntent();
  if (Intent.ACTION_SEND.equals(intent.getAction())) {
    final String log = intent.getStringExtra(Intent.EXTRA_TEXT);
    println(log);
  }
  frameRate(120);
  interface2 = new Interface();
  scene = new Scene();
}