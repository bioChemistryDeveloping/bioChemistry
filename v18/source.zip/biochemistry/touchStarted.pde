boolean click;
final void touchStarted() {
  click = true;
}