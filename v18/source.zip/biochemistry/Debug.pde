Debug debug;
final class Debug {
  private byte time;
  Debug() {
  }
  public final void update() {
    if (time < 120) {
      println("\nfps " + frameRate + "\ntotal memory " + Runtime.getRuntime().totalMemory() + "\nusing memory " + Runtime.getRuntime().freeMemory() + "\ntime " + millis() / 1000.0);
      time++;
    } else {
      time = 0;
    }
  }
}