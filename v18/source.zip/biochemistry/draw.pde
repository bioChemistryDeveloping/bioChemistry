final void draw() {
  scene.update();
  interface2.update();
  //debug.update();
}