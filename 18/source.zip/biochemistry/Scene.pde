Scene scene;
final class Scene {
  private final byte[] formattingByte(int variable) {
    return new byte[] {byte((variable >> 24) & 0xFF), byte((variable >> 16) & 0xFF), byte((variable >> 8) & 0xFF), byte(variable & 0xFF)};
  }
  private final int formattingInt(byte[] variables) {
    return ((variables[0] & 0xFF) << 24) | ((variables[1] & 0xFF) << 16) | ((variables[2] & 0xFF) << 8) | (variables[3] & 0xFF);
  }
  private final PShader background, flagellumPolygons;
  private final ArrayList<Organelle> organellesRender;
  private final class Organelle {
    private final Cell cell;
    private final byte type;
    private final float position, power;
    private float angle, time, sin, cos;
    private final boolean mirror;
    Organelle(Cell cell, byte type, float position, float power, boolean mirror) {
      this.cell = cell;
      this.type = type;
      this.position = position;
      this.power = power;
      this.mirror = mirror;
    }
    public final void update() {
      switch (type) {
        case 0 : {
          angle = position + cell.angle;
          sin = sin(angle);
          cos = cos(angle);
          cell.positionX += sin * power;
          cell.positionY += cos * power;
        }
      }
    }
    public final void render() {
      fill(cell.red & 0xFF, cell.green & 0xFF, cell.blue & 0xFF);
      normal(time, 0, 0);
      vertex((cell.positionX - sin * 2 - microscopeX)  * microscopeScale, (cell.positionY - cos * 2 - microscopeY) * microscopeScale, TWO_PI, 0);
      final float sin = sin(angle + 1.2), cos = cos(angle + 1.2);
      if (mirror) {
        vertex((cell.positionX - sin - microscopeX) * microscopeScale, (cell.positionY - cos - microscopeY) * microscopeScale, 0, -TWO_PI);
        vertex((sin + cell.positionX - microscopeX) * microscopeScale, (cos + cell.positionY - microscopeY) * microscopeScale, 0, TWO_PI);
      } else {
        vertex((cell.positionX - sin - microscopeX) * microscopeScale, (cell.positionY - cos - microscopeY) * microscopeScale, 0, TWO_PI);
        vertex((sin + cell.positionX - microscopeX) * microscopeScale, (cos + cell.positionY - microscopeY) * microscopeScale, 0, -TWO_PI);
      }
      time = (time + power * 10) % TWO_PI;
    }
  }
  private final class Logic {
    private byte[] data;
    private Logic[] patches;
    Logic(byte[] data, Logic[] patches) {
      this.data = data;
      this.patches = patches;
    }
    public final void update(Cell cell) {
      switch (data[0]) {
        case 0 : {
          if (patches[2].data[0] == patches[3].data[0]) {
            patches[0].update(cell);
          } else {
            patches[1].update(cell);
          }
          break;
        }
        case 1 : {
          if (patches[2].data[0] < patches[3].data[0]) {
            patches[0].update(cell);
          } else {
            patches[1].update(cell);
          }
          break;
        }
        case 2 : {
          if (formattingInt(patches[2].data) == formattingInt(patches[3].data)) {
            patches[0].update(cell);
          } else {
            patches[1].update(cell);
          }
          break;
        }
        case 3 : {
          if (formattingInt(patches[2].data) < formattingInt(patches[3].data)) {
            patches[0].update(cell);
          } else {
            patches[1].update(cell);
          }
          break;
        }
        case 4 : {
          switch (data[1]) {
            case 0 : {
              patches[1].data[0] = byte(patches[2].data[0]);
              break;
            }
            case 1 : {
              patches[1].data[0] = byte(patches[1].data[0] - patches[2].data[0]);
              break;
            }
            case 2 : {
              patches[1].data[0] = byte(patches[1].data[0] / patches[2].data[0]);
              break;
            }
            case 3 : {
              patches[1].data[0] = byte(patches[1].data[0] + patches[2].data[0]);
              break;
            }
            case 4 : {
              patches[1].data[0] = byte(patches[1].data[0] * patches[2].data[0]);
            }
          }
          patches[0].update(cell);
          break;
        }
        case 5 : {
          switch (data[1]) {
            case 0 : {
              patches[1].data = formattingByte(formattingInt(patches[2].data));
              break;
            }
            case 1 : {
              patches[1].data = formattingByte(formattingInt(patches[1].data) - formattingInt(patches[2].data));
              break;
            }
            case 2 : {
              patches[1].data = formattingByte(formattingInt(patches[1].data) / formattingInt(patches[2].data));
              break;
            }
            case 3 : {
              patches[1].data = formattingByte(formattingInt(patches[1].data) + formattingInt(patches[2].data));
              break;
            }
            case 4 : {
              patches[1].data = formattingByte(formattingInt(patches[1].data) * formattingInt(patches[2].data));
            }
          }
          patches[0].update(cell);
          break;
        }
        case 6 : {
          switch (data[1]) {
            case 0 : {
              patches[1].data = formattingByte(formattingInt(patches[2].data));
              break;
            }
            case 1 : {
              patches[1].data = formattingByte(Float.floatToIntBits(Float.intBitsToFloat(formattingInt(patches[1].data)) - Float.intBitsToFloat(formattingInt(patches[2].data))));
              break;
            }
            case 2 : {
              patches[1].data = formattingByte(Float.floatToIntBits(Float.intBitsToFloat(formattingInt(patches[1].data)) / Float.intBitsToFloat(formattingInt(patches[2].data))));
              break;
            }
            case 3 : {
              patches[1].data = formattingByte(Float.floatToIntBits(Float.intBitsToFloat(formattingInt(patches[1].data)) + Float.intBitsToFloat(formattingInt(patches[2].data))));
              break;
            }
            case 4 : {
              patches[1].data = formattingByte(Float.floatToIntBits(Float.intBitsToFloat(formattingInt(patches[1].data)) * Float.intBitsToFloat(formattingInt(patches[2].data))));
            }
          }
          patches[0].update(cell);
          break;
        }
        case 7 : {
          cell.logics.add(new Logic(patches[1].data.clone(), patches[1].patches.clone()));
          patches[0].update(cell);
          break;
        }
        case 8 : {
          cell.organelles.add(new Organelle(cell, patches[1].data[0], Float.intBitsToFloat(formattingInt(patches[2].data)), Float.intBitsToFloat(formattingInt(patches[3].data)), data[1] == 0 ? false : true));
          patches[0].update(cell);
          break;
        }
        case 9 : {
          cell.red = byte(patches[1].data[0]);
          patches[0].update(cell);
          break;
        }
        case 10 : {
          cell.green = byte(patches[1].data[0]);
          patches[0].update(cell);
          break;
        }
        case 11 : {
          cell.blue = byte(patches[1].data[0]);
          patches[0].update(cell);
          break;
        }
        case 12 : {
          cell.split = true;
          break;
        }
        case 13 : {
          cell.splitLinked = true;
          break;
        }
        case 14 : {
          patches[0].update(cell);
          break;
        }
        case 15 : {
          semiochemicals.add(new Semiochemical(cell, formattingInt(patches[1].data), Float.intBitsToFloat(formattingInt(patches[2].data)), Float.intBitsToFloat(formattingInt(patches[3].data))));
          patches[0].update(cell);
          break;
        }
        case 16 : {
          final int semiochemical = formattingInt(patches[1].data);
          patches[2].data = formattingByte(Float.floatToIntBits(semiochemical < cell.concentrations.size() ? cell.concentrations.get(semiochemical) : 0f));
          patches[0].update(cell);
          break;
        }
        case 17 : {
          cell.apoptosis();
          break;
        }
        case 19 : case 20 : {
          patches[0].update(cell);
        }
      }
    }
  }
  private final class Resetter {
    public final int pointer;
    public final byte[] data;
    Resetter(int pointer, byte[] data) {
      this.pointer = pointer;
      this.data = data;
    }
  }
  private Programm programm;
  private final class Programm {
    public Logic execute;
    public final ArrayList<Logic> system;
    public final ArrayList<Resetter> resetters, resetters2;
    Programm() {
      system = new ArrayList<Logic>();
      resetters = new ArrayList<Resetter>();
      resetters2 = new ArrayList<Resetter>();
    }
  }
  final Caller caller;
  private final class Caller {
    private Cell forceps;
    Caller() {
    }
    @SuppressWarnings("serial") public final void compilation() {
      final String source = interface2.source.getText().toString();
      String token = "";
      final ArrayList<String> tokens = new ArrayList<String>();
      final ArrayList<ArrayList<String>> commands = new ArrayList<ArrayList<String>>();
      for (final char character : source.toCharArray()) {
        if (character == ' ' || character == ';' || character == '{' || character == '}') {
          if (token.length() != 0) {
            tokens.add(token);
          }
          token = "";
          if (character == ';' || character == '{' || character == '}') {
            if (character == '}') {
              commands.add(new ArrayList<String>() {{add("}");}});
            } else {
              commands.add(new ArrayList<String>(tokens));
            }
            tokens.clear();
          }
        } else if (character != '\n') {
          token += character;
        }
      }
      final class Binder {
        public final String name;
        public final boolean fractional;
        public final Logic pointer;
        Binder(String name, boolean fractional, Logic pointer) {
          this.name = name;
          this.fractional = fractional;
          this.pointer = pointer;
        }
      }
      final ArrayList<Binder> binders = new ArrayList<Binder>();
      final ArrayList<Logic> compilate = new ArrayList<Logic>();
      programm = new Programm();
      for (final ArrayList<String> command : commands) {
        if (command.get(0).equals("byte")) {
          final Logic logic = new Logic(new byte[] {byte(int(command.get(2)))}, new Logic[0]);
          if (command.size() == 5 && command.get(3).equals("heirdom")) {
            if (command.get(4).equals("0")) {
              programm.resetters.add(new Resetter(programm.system.size(), logic.data));
            } else if (command.get(4).equals("1")) {
              programm.resetters2.add(new Resetter(programm.system.size(), logic.data));
            }
          } else {
            programm.resetters.add(new Resetter(programm.system.size(), logic.data));
            programm.resetters2.add(new Resetter(programm.system.size(), logic.data));
          }
          programm.system.add(logic);
          binders.add(new Binder(command.get(1), false, logic));
        } else if (command.get(0).equals("int")) {
          final Logic logic = new Logic(formattingByte(int(command.get(2))), new Logic[0]);
          if (command.size() == 5 && command.get(3).equals("heirdom")) {
            if (command.get(4).equals("0")) {
              programm.resetters.add(new Resetter(programm.system.size(), logic.data));
            } else if (command.get(4).equals("1")) {
              programm.resetters2.add(new Resetter(programm.system.size(), logic.data));
            }
          } else {
            programm.resetters.add(new Resetter(programm.system.size(), logic.data));
            programm.resetters2.add(new Resetter(programm.system.size(), logic.data));
          }
          programm.system.add(logic);
          binders.add(new Binder(command.get(1), false, logic));
        } else if (command.get(0).equals("float")) {
          final Logic logic = new Logic(formattingByte(Float.floatToRawIntBits(float(command.get(2)))), new Logic[0]);
          if (command.size() == 5 && command.get(3).equals("heirdom")) {
            if (command.get(4).equals("0")) {
              programm.resetters.add(new Resetter(programm.system.size(), logic.data));
            } else if (command.get(4).equals("1")) {
              programm.resetters2.add(new Resetter(programm.system.size(), logic.data));
            }
          } else {
            programm.resetters.add(new Resetter(programm.system.size(), logic.data));
            programm.resetters2.add(new Resetter(programm.system.size(), logic.data));
          }
          programm.system.add(logic);
          binders.add(new Binder(command.get(1), true, logic));
        } else if (command.get(0).equals("if")) {
          boolean byting = false;
          Logic variable = new Logic(new byte[0], new Logic[0]), variable2 = new Logic(new byte[0], new Logic[0]);
          if (command.get(1).charAt(0) == '-' || command.get(1).charAt(0) >= '0' && command.get(1).charAt(0) <= '9') {
            variable = new Logic(new byte[] {byte(int(command.get(1)))}, new Logic[0]);
          } else {
            for (final Binder binder : binders) {
              if (binder.name.equals(command.get(1))) {
                variable = binder.pointer;
                byting = variable.data.length == 1;
                break;
              }
            }
          }
          if (command.get(3).charAt(0) == '-' || command.get(3).charAt(0) >= '0' && command.get(3).charAt(0) <= '9') {
            if (byting) {
              variable2 = new Logic(new byte[] {byte(int(command.get(3)))}, new Logic[0]);
            } else {
              variable2 = new Logic(formattingByte(int(command.get(3))), new Logic[0]);
            }
          } else {
            for (final Binder binder : binders) {
              if (binder.name.equals(command.get(3))) {
                variable2 = binder.pointer;
                break;
              }
            }
          }
          final Logic logic = new Logic(new byte[] {variable.data.length == 1 ? byte(command.get(2).equals("==") && !command.get(2).equals("<") ? 0 : 1) : byte(command.get(2).equals("==") && !command.get(2).equals("<") ? 2 : 3)}, new Logic[] {null, null, variable, variable2});
          programm.system.add(logic);
          compilate.add(logic);
        } else if (command.get(0).equals("load")) {
          final Logic logic = new Logic(new byte[] {18}, new Logic[1]);
          programm.system.add(logic);
          compilate.add(logic);
        } else if (command.get(0).equals("return")) {
          final Logic logic = new Logic(new byte[] {19}, new Logic[1]);
          programm.system.add(logic);
          compilate.add(logic);
        } else if (command.get(0).equals("}")) {
          final Logic logic = new Logic(new byte[] {14}, new Logic[1]);
          programm.system.add(logic);
          compilate.add(logic);
        } else if (command.get(0).equals("organelle")) {
          final Logic logic = new Logic(new byte[] {8, byte(command.get(4).equals("0") ? 0 : 1)}, new Logic[4]);
          if (command.get(1).charAt(0) == '-' || command.get(1).charAt(0) >= '0' && command.get(1).charAt(0) <= '9') {
            logic.patches[1] = new Logic(new byte[] {byte(int(command.get(1)))}, new Logic[0]);
          } else {
            for (final Binder binder : binders) {
              if (binder.name.equals(command.get(1))) {
                logic.patches[1] = binder.pointer;
                break;
              }
            }
          }
          if (command.get(2).charAt(0) == '-' || command.get(2).charAt(0) >= '0' && command.get(2).charAt(0) <= '9') {
            logic.patches[2] = new Logic(formattingByte(Float.floatToRawIntBits(float(command.get(2)))), new Logic[0]);
          } else {
            for (final Binder binder : binders) {
              if (binder.name.equals(command.get(2))) {
                logic.patches[2] = binder.pointer;
                break;
              }
            }
          }
          if (command.get(3).charAt(0) == '-' || command.get(3).charAt(0) >= '0' && command.get(3).charAt(0) <= '9') {
            final Logic logic2 = new Logic(formattingByte(Float.floatToRawIntBits(float(command.get(3)))), new Logic[0]);
            logic.patches[3] = logic2;
          } else {
            for (final Binder binder : binders) {
              if (binder.name.equals(command.get(3))) {
                logic.patches[3] = binder.pointer;
                break;
              }
            }
          }
          programm.system.add(logic);
          compilate.add(logic);
        } else if (command.get(0).equals("red")) {
          if (command.get(1).charAt(0) == '-' || command.get(1).charAt(0) >= '0' && command.get(1).charAt(0) <= '9') {
            final Logic logic = new Logic(new byte[] {9}, new Logic[] {null, new Logic(new byte[] {byte(int(command.get(1)))}, new Logic[0])});
            programm.system.add(logic);
            compilate.add(logic);
          } else {
            for (final Binder binder : binders) {
              if (binder.name.equals(command.get(1))) {
                final Logic logic = new Logic(new byte[] {9}, new Logic[] {null, binder.pointer});
                programm.system.add(logic);
                compilate.add(logic);
                break;
              }
            }
          }
        } else if (command.get(0).equals("green")) {
          if (command.get(1).charAt(0) == '-' || command.get(1).charAt(0) >= '0' && command.get(1).charAt(0) <= '9') {
            final Logic logic = new Logic(new byte[] {10}, new Logic[] {null, new Logic(new byte[] {byte(int(command.get(1)))}, new Logic[0])});
            programm.system.add(logic);
            compilate.add(logic);
          } else {
            for (final Binder binder : binders) {
              if (binder.name.equals(command.get(1))) {
                final Logic logic = new Logic(new byte[] {10}, new Logic[] {null, binder.pointer});
                programm.system.add(logic);
                compilate.add(logic);
                break;
              }
            }
          }
        } else if (command.get(0).equals("blue")) {
          if (command.get(1).charAt(0) == '-' || command.get(1).charAt(0) >= '0' && command.get(1).charAt(0) <= '9') {
            final Logic logic = new Logic(new byte[] {11}, new Logic[] {null, new Logic(new byte[] {byte(int(command.get(1)))}, new Logic[0])});
            programm.system.add(logic);
            compilate.add(logic);
          } else {
            for (final Binder binder : binders) {
              if (binder.name.equals(command.get(1))) {
                final Logic logic = new Logic(new byte[] {11}, new Logic[] {null, binder.pointer});
                programm.system.add(logic);
                compilate.add(logic);
                break;
              }
            }
          }
        } else if (command.get(0).equals("diffusion")) {
          final Logic logic = new Logic(new byte[] {15}, new Logic[4]);
          if (command.get(1).charAt(0) == '-' || command.get(1).charAt(0) >= '0' && command.get(1).charAt(0) <= '9') {
            logic.patches[1] = new Logic(formattingByte(int(command.get(1))), new Logic[0]);
          } else {
            for (final Binder binder : binders) {
              if (binder.name.equals(command.get(1))) {
                logic.patches[1] = binder.pointer;
                break;
              }
            }
          }
          if (command.get(2).charAt(0) == '-' || command.get(2).charAt(0) >= '0' && command.get(2).charAt(0) <= '9') {
            logic.patches[2] = new Logic(formattingByte(Float.floatToRawIntBits(float(command.get(2)))), new Logic[0]);
          } else {
            for (final Binder binder : binders) {
              if (binder.name.equals(command.get(2))) {
                logic.patches[2] = binder.pointer;
                break;
              }
            }
          }
          if (command.get(3).charAt(0) == '-' || command.get(3).charAt(0) >= '0' && command.get(3).charAt(0) <= '9') {
            logic.patches[3] = new Logic(formattingByte(Float.floatToRawIntBits(float(command.get(3)))), new Logic[0]);
          } else {
            for (final Binder binder : binders) {
              if (binder.name.equals(command.get(3))) {
                logic.patches[3] = binder.pointer;
                break;
              }
            }
          }
          programm.system.add(logic);
          compilate.add(logic);
        } else if (command.get(0).equals("detect")) {
          final Logic logic = new Logic(new byte[] {16}, new Logic[4]);
          if (command.get(1).charAt(0) == '-' || command.get(1).charAt(0) >= '0' && command.get(1).charAt(0) <= '9') {
            logic.patches[1] = new Logic(formattingByte(int(command.get(1))), new Logic[0]);
          } else {
            for (final Binder binder : binders) {
              if (binder.name.equals(command.get(1))) {
                logic.patches[1] = binder.pointer;
                break;
              }
            }
          }
          if (command.get(2).charAt(0) == '-' || command.get(2).charAt(0) >= '0' && command.get(2).charAt(0) <= '9') {
            logic.patches[2] = new Logic(formattingByte(int(command.get(2))), new Logic[0]);
          } else {
            for (final Binder binder : binders) {
              if (binder.name.equals(command.get(2))) {
                logic.patches[2] = binder.pointer;
                break;
              }
            }
          }
          programm.system.add(logic);
          compilate.add(logic);
        } else if (command.get(0).equals("red")) {
          if (command.get(1).charAt(0) == '-' || command.get(1).charAt(0) >= '0' && command.get(1).charAt(0) <= '9') {
            final Logic logic = new Logic(new byte[] {9}, new Logic[] {null, new Logic(new byte[] {byte(int(command.get(1)))}, new Logic[0])});
            programm.system.add(logic);
            compilate.add(logic);
          } else {
            for (final Binder binder : binders) {
              if (binder.name.equals(command.get(1))) {
                final Logic logic = new Logic(new byte[] {9}, new Logic[] {null, binder.pointer});
                programm.system.add(logic);
                compilate.add(logic);
                break;
              }
            }
          }
        } else if (command.get(0).equals("break")) {
          final Logic logic = new Logic(new byte[] {18}, new Logic[0]);
          programm.system.add(logic);
          compilate.add(logic);
        } else if (command.get(0).equals("split")) {
          final Logic logic = new Logic(new byte[] {byte(command.get(1).equals("0") && !command.get(1).equals("1") ? 12 : 13)}, new Logic[1]);
          programm.system.add(logic);
          compilate.add(logic);
        } else if (command.get(0).equals("apoptosis")) {
          final Logic logic = new Logic(new byte[] {17}, new Logic[0]);
          programm.system.add(logic);
          compilate.add(logic);
        } else {
          for (final Binder binder : binders) {
            if (binder.name.equals(command.get(0))) {
              if (binder.pointer.data.length == 1) {
                if (command.get(1).charAt(0) == '-' || command.get(1).charAt(0) >= '0' && command.get(1).charAt(0) <= '9') {
                  final Logic constant = new Logic(new byte[] {byte(int(command.get(1)))}, new Logic[0]), formula = new Logic(new byte[] {4, 0}, new Logic[] {null, binder.pointer, constant});
                  programm.system.add(formula);
                  compilate.add(formula);
                } else {
                  for (final Binder binder2 : binders) {
                    if (binder2.name.equals(command.get(1))) {
                      final Logic formula = new Logic(new byte[] {4, 0}, new Logic[] {null, binder.pointer, binder2.pointer});
                      programm.system.add(formula);
                      compilate.add(formula);
                      break;
                    }
                  }
                }
                for (int formula = 2; formula + 1 < command.size(); formula += 2) {
                  final Logic operator = new Logic(new byte[] {4, byte(command.get(formula).equals("-") ? 1 : command.get(formula).equals("/") ? 2 : command.get(formula).equals("+") ? 3 : command.get(formula).equals("*") ? 4 : 5)}, null);
                  final int formula2 = formula + 1;
                  if (command.get(formula2).charAt(0) == '-' || command.get(formula2).charAt(0) >= '0' && command.get(formula2).charAt(0) <= '9') {
                    final Logic constant = new Logic(new byte[] {byte(int(command.get(formula2)))}, new Logic[0]);
                    operator.patches = new Logic[] {null, binder.pointer, constant};
                    programm.system.add(operator);
                    compilate.add(operator);
                  } else {
                    for (final Binder binder2 : binders) {
                      if (binder2.name.equals(command.get(formula2))) {
                        operator.patches = new Logic[] {null, binder.pointer, binder2.pointer};
                        programm.system.add(operator);
                        compilate.add(operator);
                        break;
                      }
                    }
                  }
                }
              } else {
                if (binder.fractional) {
                  if (command.get(1).charAt(0) == '-' || command.get(1).charAt(0) >= '0' && command.get(1).charAt(0) <= '9') {
                    final Logic constant = new Logic(formattingByte(Float.floatToRawIntBits(float(command.get(1)))), new Logic[0]), formula = new Logic(new byte[] {6, 0}, new Logic[] {null, binder.pointer, constant});
                    programm.system.add(formula);
                    compilate.add(formula);
                  } else {
                    for (final Binder binder2 : binders) {
                      if (binder2.name.equals(command.get(1))) {
                        final Logic formula = new Logic(new byte[] {6, 0}, new Logic[] {null, binder.pointer, binder2.pointer});
                        programm.system.add(formula);
                        compilate.add(formula);
                        break;
                      }
                    }
                  }
                  for (int formula = 2; formula + 1 < command.size(); formula += 2) {
                    final Logic operator = new Logic(new byte[] {6, byte(command.get(formula).equals("-") ? 1 : command.get(formula).equals("/") ? 2 : command.get(formula).equals("+") ? 3 : command.get(formula).equals("*") ? 4 : 5)}, null);
                    final int formula2 = formula + 1;
                    if (command.get(formula2).charAt(0) == '-' || command.get(formula2).charAt(0) >= '0' && command.get(formula2).charAt(0) <= '9') {
                      final Logic constant = new Logic(formattingByte(Float.floatToRawIntBits(float(command.get(formula2)))), new Logic[0]);
                      operator.patches = new Logic[] {null, binder.pointer, constant};
                      programm.system.add(operator);
                      compilate.add(operator);
                    } else {
                      for (final Binder binder2 : binders) {
                        if (binder2.name.equals(command.get(formula2))) {
                          operator.patches = new Logic[] {null, binder.pointer, binder2.pointer};
                          programm.system.add(operator);
                          compilate.add(operator);
                          break;
                        }
                      }
                    }
                  }
                } else {
                  if (command.get(1).charAt(0) == '-' || command.get(1).charAt(0) >= '0' && command.get(1).charAt(0) <= '9') {
                    final Logic constant = new Logic(formattingByte(int(command.get(1))), new Logic[0]), formula = new Logic(new byte[] {5, 0}, new Logic[] {null, binder.pointer, constant});
                    programm.system.add(formula);
                    compilate.add(formula);
                  } else {
                    for (final Binder binder2 : binders) {
                      if (binder2.name.equals(command.get(1))) {
                        final Logic formula = new Logic(new byte[] {5, 0}, new Logic[] {null, binder.pointer, binder2.pointer});
                        programm.system.add(formula);
                        compilate.add(formula);
                        break;
                      }
                    }
                  }
                  for (int formula = 2; formula + 1 < command.size(); formula += 2) {
                    final Logic operator = new Logic(new byte[] {5, byte(command.get(formula).equals("-") ? 1 : command.get(formula).equals("/") ? 2 : command.get(formula).equals("+") ? 3 : command.get(formula).equals("*") ? 4 : 5)}, null);
                    final int formula2 = formula + 1;
                    if (command.get(formula2).charAt(0) == '-' || command.get(formula2).charAt(0) >= '0' && command.get(formula2).charAt(0) <= '9') {
                      final Logic constant = new Logic(formattingByte(int(command.get(formula2))), new Logic[0]);
                      operator.patches = new Logic[] {null, binder.pointer, constant};
                      programm.system.add(operator);
                      compilate.add(operator);
                    } else { 
                      for (final Binder binder2 : binders) {
                        if (binder2.name.equals(command.get(formula2))) {
                          operator.patches = new Logic[] {null, binder.pointer, binder2.pointer};
                          programm.system.add(operator);
                          compilate.add(operator);
                          break;
                        }
                      }
                    }
                  }
                }
              }
              break;
            }
          }
        }
      }
      programm.execute = compilate.get(0);
      final ArrayList<Logic> union = new ArrayList<Logic>(), cycle = new ArrayList<Logic>();
      for (int logic = 0; logic < compilate.size(); logic++) {
        if (compilate.get(logic).data[0] < 17) {
          compilate.get(logic).patches[0] = compilate.get(logic + 1);
          if (compilate.get(logic).data[0] < 4) {
            union.add(compilate.get(logic));
          } else if (compilate.get(logic).data[0] == 14) {
            final int space = union.size() - 1;
            union.get(space).patches[1] = compilate.get(logic + 1);
            union.remove(space);
          }
        } else if (compilate.get(logic).data[0] == 19) {
          compilate.get(logic).patches[0] = compilate.get(logic + 1);
          cycle.add(compilate.get(logic));
        } else if (compilate.get(logic).data[0] == 20) {
          final int space = cycle.size() - 1;
          compilate.get(logic).patches[0] = cycle.get(space).patches[0];
          cycle.remove(space);
        }
      }
    }
    private float offsetX, offsetY;
    public final void update(byte mode, TouchEvent.Pointer touch) {
      switch (mode) {
        case 0 : {
          final float touchX = touch.x / microscopeScale + microscopeX, touchY = touch.y / microscopeScale + microscopeY;
          if (click) {
            offsetX = touchX;
            offsetY = touchY;
            click = false;
          }
          microscopeX += offsetX - touchX;
          microscopeY += offsetY - touchY;
          break;
        }
        case 1 : {
          final float touchX = touch.x / microscopeScale + microscopeX, touchY = touch.y / microscopeScale + microscopeY;
          for (final Cell cell : cells) {
            if (dist(cell.positionX, cell.positionY, touchX, touchY) < 1) {
              forceps = cell;
              break;
            }
          }
          if (forceps != null) {
            forceps.positionX = touchX;
            forceps.positionY = touchY;
          }
          break;
        }
        case 2 : {
          cells.add(new Cell(programm.execute, programm.system, 0, 0, 0, touch.x / microscopeScale + microscopeX, touch.y / microscopeScale + microscopeY, byte(random(255)), byte(random(255)), byte(random(255)), programm.resetters, programm.resetters2, false));
          break;
        }
        case 3 : {
          for (final Cell cell : cells) {
            if (dist(cell.positionX, cell.positionY, touch.x / microscopeScale + microscopeX, touch.y / microscopeScale + microscopeY) < 1) {
              cell.apoptosis();
              break;
            }
          }
          break;
        }
        case 4 : {
          
          break;
        }
        case 5 : {
          
          break;
        }
        case 6 : {
          compilation();
          break;
        }
        case 7 : {
          
          break;
        }
        case 8 : {
          
        }
      }
    }
    public final void cleanUp() {
      organics.clear();
      for (final Cell cell : cells) {
        cell.apoptosis();
      }
    }
    public final void zoom(float distance) {
      microscopeScale += distance * microscopeScale;
    }
  }
  private final ArrayList<Space> spacesUsing;
  private final Space[][] spaces;
  private final class Space {
    private int positionX, positionY;
    public ArrayList<Cell> cellsUpdate;
    public final ArrayList<Cell> cells;
    Space(int positionX, int positionY) {
      this.positionX = positionX;
      this.positionY = positionY;
      cells = new ArrayList<Cell>();
      cellsUpdate = new ArrayList<Cell>();
    }
    public final void update() {
      for (int cell = 0; cell < cells.size(); cell++) {
        for (int cell2 = 0; cell2 < cells.size(); cell2++) {
          if (cell != cell2 && abs(cells.get(cell).positionX - cells.get(cell2).positionX) < 1 && abs(cells.get(cell).positionY - cells.get(cell2).positionY) < 1) {
            final float distance = sq(dist(cells.get(cell).positionX, cells.get(cell).positionY, cells.get(cell2).positionX, cells.get(cell2).positionY) + 1) * 15;
            if (distance < 60 && int((cells.get(cell).positionX + cells.get(cell2).positionX) / 8) == positionX && int((cells.get(cell).positionY + cells.get(cell2).positionY) / 8) == positionY) {
              cellsUpdate.get(cell).velocityX += (cells.get(cell).positionX - cells.get(cell2).positionX) / distance;
              cellsUpdate.get(cell).velocityY += (cells.get(cell).positionY - cells.get(cell2).positionY) / distance;
            }
          }
        }
      }
      cells.clear();
    }
  }
  private float microscopeX, microscopeY;
  public float microscopeScale;
  private final PShader semiochemicalsPolygons;
  private final ArrayList<Semiochemical> semiochemicals, semiochemicalsRemoved;
  private final class Semiochemical {
    private final Cell source;
    public final int molecule;
    private final float radius, radius2, diffusion;
    private float concentration;
    Semiochemical(Cell source, int molecule, float radius, float diffusion) {
      this.source = source;
      this.molecule = molecule;
      this.radius = radius;
      radius2 = radius * 2;
      this.diffusion = diffusion;
      concentration = 1;
    }
    public final void update() {
      if (concentration > 0) {
        for (float x = -radius; x < radius; x++) {
          for (float y = -radius; y < radius; y++) {
            final int spaceX = int(x + source.positionX / 4), spaceY = int(y + source.positionY / 4);
            if (spaceX >= 0 && spaceX < spaces.length && spaceY >= 0 && spaceY < spaces[spaceX].length) {
              for (final Cell cell : spaces[spaceX][spaceY].cellsUpdate) {
                if (cell != source) {
                  final float distance = dist(cell.positionX, cell.positionY, source.positionX, source.positionY);
                  if (distance < radius2) {
                    if (molecule < cell.concentrations.size()) {
                      cell.concentrations.set(molecule, radius / (distance + 1));
                    } else {
                      for (int concentration = cell.concentrations.size(); concentration < molecule; concentration++) {
                        cell.concentrations.add(0f);
                      }
                      cell.concentrations.add(radius / (distance + 1));
                    }
                  }
                }
              }
            }
          }
        }
        concentration -= diffusion;
      } else {
        semiochemicalsRemoved.add(this);
      }
    }
    public final void render() {
      fill(source.red & 0xFF, source.green & 0xFF, source.blue & 0xFF, concentration * 255);
      final float coordinatesX = (source.positionX - microscopeX) * microscopeScale, coordinatesY = (source.positionY - microscopeY) * microscopeScale, resolution = 1.1547005 * microscopeScale * radius2, microscopeScaleDouble = microscopeScale * 2 * radius2;
      vertex(coordinatesX - resolution, coordinatesY - microscopeScaleDouble, -0.5773502692, -1);
      vertex(coordinatesX - resolution, coordinatesY + microscopeScaleDouble, -0.5773502692, 1);
      vertex(coordinatesX + 2.309401 * microscopeScale * radius2, coordinatesY, 1.1547005, 0);
    }
  }
  private final PShader organicsPolygons;
  private final ArrayList<Organic> organics;
  private final class Organic {
    final float positionX, positionY;
    final byte red, green, blue;
    Organic(float positionX, float positionY) {
      this.positionX = positionX;
      this.positionY = positionY;
      red = byte(noise(positionX, positionY) * 200);
      green = byte(noise(positionY, positionX) * 100);
      blue = byte(noise(-positionX, positionY) * 50);
    }
    public final void update() {
      fill(red & 0xFF, green & 0xFF, blue & 0xFF);
      final float coordinatesX = (positionX - microscopeX) * microscopeScale, coordinatesY = (positionY - microscopeY) * microscopeScale, resolution = 1.1547005 * microscopeScale, microscopeScaleDouble = microscopeScale * 2;
      vertex(coordinatesX - resolution, coordinatesY - microscopeScaleDouble, -0.5773502692, -1);
      vertex(coordinatesX - resolution, coordinatesY + microscopeScaleDouble, -0.5773502692, 1);
      vertex(coordinatesX + 2.309401 * microscopeScale, coordinatesY, 1.1547005, 0);
    }
  }
  private final PShader linksPolygons;
  private final ArrayList<Link> linksRemoved, links;
  private final class Link {
    private Cell cell, cell2;
    private byte red, green, blue;
    Link(Cell cell, Cell cell2) {
      this.cell = cell;
      this.cell2 = cell2;
      cell.adjacent.add(this);
      cell2.adjacent.add(this);
    }
    public final void apoptosis() {
      linksRemoved.add(this);
      particles.add(new Particle((cell.velocityX + cell2.velocityX) / 2, (cell.velocityY + cell2.velocityY) / 2, (cell.positionX + cell2.positionX) / 2, (cell.positionY + cell2.positionY) / 2, byte(red & 0xFF), byte(green & 0xFF), byte(blue & 0xFF)));
    }
    public final void update() {
      final float distance = sq(dist(cell.positionX, cell.positionY, cell2.positionX, cell2.positionY) - 1) * 0.05;
      red = byte((cell.red + cell2.red) / 2);
      green = byte((cell.green + cell2.green) / 2);
      blue = byte((cell.blue + cell2.blue) / 2);
      if (distance > 0.5) {
        apoptosis();
      } else {
        final float averageX = cell.positionX - cell2.positionX, averageY = cell.positionY - cell2.positionY, rotate = atan2(averageX, averageY);
        if (distance > 0) {
          final float pullsX = averageX * distance, pullsY = averageY * distance;
          cell.angle = rotate;
          cell.stretchingX -= pullsX;
          cell.stretchingY -= pullsY;
          cell2.angle = rotate;
          cell2.stretchingX += pullsX;
          cell2.stretchingY += pullsY;
        }
        fill(red & 0xFF, green & 0xFF, blue & 0xFF);
        final float sin = sin(-rotate) / 2, cos = cos(-rotate) / 2;
        vertex((cell.positionX - cos - microscopeX) * microscopeScale, (cell.positionY - sin - microscopeY) * microscopeScale, 0, PI);
        vertex((cell2.positionX - cos - microscopeX) * microscopeScale, (cell2.positionY - sin - microscopeY) * microscopeScale, 0, 0);
        vertex((cell2.positionX + cos - microscopeX) * microscopeScale, (cell2.positionY + sin - microscopeY) * microscopeScale, PI, 0);
        vertex((cell.positionX + cos - microscopeX) * microscopeScale, (cell.positionY + sin - microscopeY) * microscopeScale, PI, PI);
      }
    }
  }
  private final PShader cellsPolygons;
  private final ArrayList<Cell> cellsAdded, cellsRemoved;
  private ArrayList<Cell> cellsUpdate, cells;
  private final class Cell {
    public final ArrayList<Float> concentrations;
    private final ArrayList<Logic> logics;
    public boolean split, splitLinked;
    private byte constructor;
    public final ArrayList<Organelle> organelles;
    private final Logic execute;
    public float angle, velocityX, velocityY, stretchingX, stretchingY, positionX, positionY;
    public byte red, green, blue;
    public final ArrayList<Link> adjacent;
    private final Logic split(Logic logic, java.util.IdentityHashMap<Logic, Logic> links) {
      if (logic == null) {
        return null;
      }
      Logic added = links.get(logic);
      if (added != null) {
        return added;
      }
      added = new Logic(logic.data.clone(), new Logic[logic.patches.length]);
      links.put(logic, added);
      for (int patch = 0; patch < logic.patches.length; patch++) {
        added.patches[patch] = split(logic.patches[patch], links);
      }
      return added;
    }
    public final ArrayList<Resetter> resetters, resetters2;
    Cell(Logic execute, ArrayList<Logic> logics, float angle, float velocityX, float velocityY, float positionX, float positionY, byte red, byte green, byte blue, ArrayList<Resetter> resetters, ArrayList<Resetter> resetters2, boolean side) {
      concentrations = new ArrayList<Float>();
      final java.util.IdentityHashMap<Logic, Logic> logicsLinks = new java.util.IdentityHashMap<Logic, Logic>();
      final ArrayList<Logic> logicsAdded = new ArrayList<Logic>();
      for (final Logic logic : logics) {
        logicsAdded.add(split(logic, logicsLinks));
      }
      this.logics = logicsAdded;
      this.execute = split(execute, logicsLinks);
      organelles = new ArrayList<Organelle>();
      this.angle = angle;
      this.velocityX = velocityX;
      this.velocityY = velocityY;
      this.positionX = positionX;
      this.positionY = positionY;
      this.red = red;
      this.green = green;
      this.blue = blue;
      this.resetters = new ArrayList<Resetter>();
      for (Resetter resetter : resetters) {
        this.resetters.add(new Resetter(resetter.pointer, resetter.data.clone()));
        if (side) {
          this.logics.get(resetter.pointer).data = resetter.data.clone();
        }
      }
      this.resetters2 = new ArrayList<Resetter>();
      for (Resetter resetter : resetters2) {
        this.resetters2.add(new Resetter(resetter.pointer, resetter.data.clone()));
        if (!side) {
          this.logics.get(resetter.pointer).data = resetter.data.clone();
        }
      }
      adjacent = new ArrayList<Link>();
    }
    public final void apoptosis() {
      cellsRemoved.add(this);
      for (final Link link : adjacent) {
        link.apoptosis();
      }
      particles.add(new Particle(velocityX, velocityY, positionX, positionY, red, green, blue));
    }
    public final void update() {
      if (split) {
        if (constructor == 50) {
          final float angleSplit = random(TWO_PI), sin = sin(angleSplit) / 50, cos = cos(angleSplit) / 50;
          cellsAdded.add(new Cell(execute, logics, angle, velocityX - sin, velocityY - cos, positionX, positionY, red, green, blue, resetters, resetters2, false));
          cellsAdded.add(new Cell(execute, logics, angle, velocityX + sin, velocityY + cos, positionX, positionY, red, green, blue, resetters, resetters2, true));
          apoptosis();
        } else {
          constructor++;
        }
      } else if (splitLinked) {
        if (constructor == 50) {
          final float angleSplit = random(TWO_PI), sin = sin(angleSplit) / 50, cos = cos(angleSplit) / 50;
          final Cell added = new Cell(execute, logics, angle, velocityX - sin, velocityY - cos, positionX, positionY, red, green, blue, resetters, resetters2, false), added2 = new Cell(execute, logics, angle, velocityX + sin, velocityY + cos, positionX, positionY, red, green, blue, resetters, resetters2, true);
          cellsAdded.add(added);
          cellsAdded.add(added2);
          links.add(new Link(added, added2));
          for (final Link link : adjacent) {
            if (link.cell == this) {
              link.cell = added;
            } else {
              link.cell2 = added;
            }
            added.adjacent.add(link);
          }
          cellsRemoved.add(this);
        } else {
          constructor++;
        }
      } else {
        execute.update(this);
      }
      for (final Organelle organelle : organelles) {
        organelle.update();
      }
      positionX += velocityX + stretchingX;
      positionY += velocityY + stretchingY;
      velocityX *= 0.98;
      velocityY *= 0.98;
      stretchingX *= 0.7;
      stretchingY *= 0.7;
      final float distance = dist(positionX, positionY, 60, 60);
      if (distance > 29.5) {
        final float velocity = -abs(velocityX) - abs(velocityY), angle = atan2(positionX - 60, positionY - 60), sin = sin(angle), cos = cos(angle);
        velocityX = sin * velocity;
        velocityY = cos * velocity;
        positionX = sin * 29.5 + 60;
        positionY = cos * 29.5 + 60;
      }
      for (float x = positionX - 0.5; x < positionX + 0.6; x += 0.5) {
        for (float y = positionY - 0.5; y < positionY + 0.6; y += 0.5) {
          final int roundedX = int(x / 4), roundedY = int(y / 4);
          while (spacesUsing.remove(spaces[roundedX][roundedY])) {
          }
          final Space space = spaces[roundedX][roundedY];
          if (!space.cells.contains(this)) {
            space.cells.add(this);
          }
          spacesUsing.add(space);
          space.cellsUpdate = new ArrayList<Cell>(space.cells);
        }
      }
      fill(red & 0xFF, green & 0xFF, blue & 0xFF);
      final float coordinatesX = (positionX - microscopeX) * microscopeScale, coordinatesY = (positionY - microscopeY) * microscopeScale, resolution = 0.5773502692 * microscopeScale;
      vertex(coordinatesX - resolution, coordinatesY - microscopeScale, -0.5773502692, -1);
      vertex(coordinatesX - resolution, coordinatesY + microscopeScale, -0.5773502692, 1);
      vertex(coordinatesX + 1.1547005 * microscopeScale, coordinatesY, 1.1547005, 0);
      for (final Organelle organelle : organelles) {
        organellesRender.add(organelle);
      }
      for (int concentration = 0; concentration < concentrations.size(); concentration++) {
        concentrations.set(concentration, concentrations.get(concentration) * 0.9);
      }
    }
  }
  private final PShader particlesPolygons;
  private final ArrayList<Particle> particlesRemoved, particles;
  private final class Particle {
    private float velocityX, velocityY, positionX, positionY;
    private byte time, red, green, blue;
    Particle(float velocityX, float velocityY, float positionX, float positionY, byte red, byte green, byte blue) {
      this.velocityX = velocityX;
      this.velocityY = velocityY;
      this.positionX = positionX;
      this.positionY = positionY;
      time = 127;
      this.red = red;
      this.green = green;
      this.blue = blue;
    }
    public final void update() {
      if (time == -1) {
        particlesRemoved.add(this);
      } else {
        positionX += velocityX;
        positionY += velocityY;
        velocityX *= 0.98;
        velocityY *= 0.98;
        fill(red & 0xFF, green & 0xFF, blue & 0xFF, time);
        final float coordinatesX = (positionX - microscopeX) * microscopeScale, coordinatesY = (positionY - microscopeY) * microscopeScale, resolution = 1.1547005 * microscopeScale, microscopeScaleDouble = microscopeScale * 2;
        vertex(coordinatesX - resolution, coordinatesY - microscopeScaleDouble, -0.5773502692, -1);
        vertex(coordinatesX - resolution, coordinatesY + microscopeScaleDouble, -0.5773502692, 1);
        vertex(coordinatesX + 2.309401 * microscopeScale, coordinatesY, 1.1547005, 0);
        time -= 4;
      }
    }
  }
  Scene() {
    background = loadShader("background.fragment", "background.vertex");
    caller = new Caller();
    caller.compilation();
    spacesUsing = new ArrayList<Space>();
    spaces = new Space[30][30];
    for (int x = 0; x < spaces.length; x++) {
      for (int y = 0; y < spaces[x].length; y++) {
        spaces[x][y] = new Space(x, y);
      }
    }
    semiochemicalsRemoved = new ArrayList<Semiochemical>();
    microscopeX = 15;
    microscopeY = 15;
    microscopeScale = 30;
    semiochemicalsPolygons = loadShader("semiochemicals.fragment", "semiochemicals.vertex");
    semiochemicals = new ArrayList<Semiochemical>();
    organicsPolygons = loadShader("organics.fragment", "organics.vertex");
    organics = new ArrayList<Organic>();
    linksRemoved = new ArrayList<Link>();
    linksPolygons = loadShader("links.fragment", "links.vertex");
    links = new ArrayList<Link>();
    cellsPolygons = loadShader("cells.fragment", "cells.vertex");
    noStroke();
    textureMode(NORMAL);
    cellsAdded = new ArrayList<Cell>();
    cellsRemoved = new ArrayList<Cell>();
    cells = new ArrayList<Cell>();
    flagellumPolygons = loadShader("flagellum.fragment", "flagellum.vertex");
    organellesRender = new ArrayList<Organelle>();
    particlesRemoved = new ArrayList<Particle>();
    particlesPolygons = loadShader("particles.fragment", "particles.vertex");
    particles = new ArrayList<Particle>();
  }
  public final void update() {
    final float right = width / microscopeScale + microscopeX, bottom = height / microscopeScale + microscopeY;
    background.set("scale", microscopeScale);
    shader(background);
    beginShape();
    vertex(0, 0, microscopeX, microscopeY);
    vertex(width, 0, right, microscopeY);
    vertex(width, height, right, bottom);
    vertex(0, height, microscopeX, bottom);
    endShape();
    for (final Semiochemical semiochemical : semiochemicals) {
      semiochemical.update();
    }
    shader(organicsPolygons);
    beginShape(TRIANGLES);
    for (final Organic organic : organics) {
      organic.update();
    }
    endShape();
    shader(linksPolygons);
    beginShape(QUAD);
    for (final Link link : links) {
      link.update();
    }
    endShape();
    cellsUpdate = new ArrayList<Cell>(cells);
    shader(cellsPolygons);
    beginShape(TRIANGLES);
    for (final Cell cell : cells) {
      cell.update();
    }
    endShape();
    shader(flagellumPolygons);
    beginShape(TRIANGLES);
    for (final Organelle organelle : organellesRender) {
      organelle.render();
    }
    endShape();
    for (final Space space : spacesUsing) {
      space.update();
    }
    spacesUsing.clear();
    links.removeAll(linksRemoved);
    linksRemoved.clear();
    cells = new ArrayList<Cell>(cellsUpdate);
    cells.addAll(cellsAdded);
    cellsAdded.clear();
    while (organics.size() < 2000) {
      final float radius = random(30);
      for (byte count = 0; count < radius; count++) {
        final float angle = random(TWO_PI), difference = radius + random(-0.5, 0.5);
        organics.add(new Organic(sin(angle) * difference + 60, cos(angle) * difference + 60));
      }
    }
    shader(particlesPolygons);
    beginShape(TRIANGLES);
    for (final Particle particle : particles) {
      particle.update();
    }
    endShape();
    semiochemicals.removeAll(semiochemicalsRemoved);
    semiochemicalsRemoved.clear();
    shader(semiochemicalsPolygons);
    beginShape(TRIANGLES);
    for (final Semiochemical semiochemical : semiochemicals) {
      semiochemical.render();
    }
    endShape();
    resetShader();
    cells.removeAll(cellsRemoved);
    cellsRemoved.clear();
    particles.removeAll(particlesRemoved);
    particlesRemoved.clear();
    organellesRender.clear();
  }
}