Scene scene;
final class Scene {
  private final byte[] formattingByte(int variable) {
    return new byte[] {byte((variable >> 24) & 0xFF), byte((variable >> 16) & 0xFF), byte((variable >> 8) & 0xFF), byte(variable & 0xFF)};
  }
  private final int formattingInt(byte[] variables) {
    return ((variables[0] & 0xFF) << 24) | ((variables[1] & 0xFF) << 16) | ((variables[2] & 0xFF) << 8) | (variables[3] & 0xFF);
  }
  private final PShader background, organellesPolygons;
  private final ArrayList<Organelle> organellesRender;
  private final class Organelle {
    private final Cell cell;
    private final byte type;
    private final float position, power;
    private float angle, time, sin, cos;
    private final boolean mirror;
    Organelle(Cell cell, byte type, float position, float power, boolean mirror) {
      this.cell = cell;
      this.type = type;
      this.position = position;
      this.power = power;
      this.mirror = mirror;
    }
    public final void update() {
      angle = position + cell.angle;
      sin = sin(angle);
      cos = cos(angle);
      switch (type) {
        case 0 : {
          for (final Organic organic : cell.organics) {
            final float distance = sq(sq(dist(organic.positionX, organic.positionY, cell.positionX, cell.positionY))), indraught = power / distance;
            organic.positionX -= (organic.positionX - cell.positionX) * indraught;
            organic.positionY -= (organic.positionY - cell.positionY) * indraught;
            if (distance < 0.01) {
              organicsRemoved.add(organic);
              cell.mass++;
            }
          }
          break;
        }
        case 1 : {
          break;
        }
        case 2 : {
          cell.positionX += sin * power;
          cell.positionY += cos * power;
        }
      }
      cell.mass -= abs(power);
    }
    public final void render() {
      fill(cell.red & 0xFF, cell.green & 0xFF, cell.blue & 0xFF);
      normal(type, time, 0);
      vertex((cell.positionX - sin * 2 - microscopeX)  * microscopeScale, (cell.positionY - cos * 2 - microscopeY) * microscopeScale, TWO_PI, 0);
      final float sin = sin(angle + 1.2), cos = cos(angle + 1.2);
      if (mirror) {
        vertex((cell.positionX - sin - microscopeX) * microscopeScale, (cell.positionY - cos - microscopeY) * microscopeScale, 0, -TWO_PI);
        vertex((sin + cell.positionX - microscopeX) * microscopeScale, (cos + cell.positionY - microscopeY) * microscopeScale, 0, TWO_PI);
      } else {
        vertex((cell.positionX - sin - microscopeX) * microscopeScale, (cell.positionY - cos - microscopeY) * microscopeScale, 0, TWO_PI);
        vertex((sin + cell.positionX - microscopeX) * microscopeScale, (cos + cell.positionY - microscopeY) * microscopeScale, 0, -TWO_PI);
      }
      time = (time + power * 10) % TWO_PI;
    }
  }
  final Logic pi;
  private final class Logic {
    public byte[] data;
    public Logic[] patches;
    Logic(byte[] data, Logic[] patches) {
      this.data = data;
      this.patches = patches;
    }
    public final void update(Cell cell) {
      switch (data[0]) {
        case -14 : {
          cell.splitLinked = true;
          cell.splitAngle = Float.intBitsToFloat(formattingInt(patches[1].data)) * 0.017453292384;
          break;
        }
        case -13 : {
          cell.split = true;
          cell.splitAngle = Float.intBitsToFloat(formattingInt(patches[1].data)) * 0.017453292384;
          break;
        }
        case -8 : {
          cell.organelles.add(new Organelle(cell, patches[1].data[0], Float.intBitsToFloat(formattingInt(patches[2].data)) * 0.017453292384, Float.intBitsToFloat(formattingInt(patches[3].data)), data[1] == 0 ? false : true));
          patches[0].update(cell);
          break;
        }
        case 0 : {
          switch (data[1]) {
            case 0 : {
              if (patches[2].data[0] == patches[3].data[0]) {
                patches[0].update(cell);
              } else {
                patches[1].update(cell);
              }
              break;
            }
            case 1 : {
              if (patches[2].data[0] < patches[3].data[0]) {
                patches[0].update(cell);
              } else {
                patches[1].update(cell);
              }
              break;
            }
            case 2 : {
              if (patches[2].data[0] > patches[3].data[0]) {
                patches[0].update(cell);
              } else {
                patches[1].update(cell);
              }
              break;
            }
            case 3 : {
              if (patches[2].data[0] != patches[3].data[0]) {
                patches[0].update(cell);
              } else {
                patches[1].update(cell);
              }
              break;
            }
            case 4 : {
              if (patches[2].data[0] <= patches[3].data[0]) {
                patches[0].update(cell);
              } else {
                patches[1].update(cell);
              }
              break;
            }
            case 5 : {
              if (patches[2].data[0] >= patches[3].data[0]) {
                patches[0].update(cell);
              } else {
                patches[1].update(cell);
              }
            }
          }
          break;
        }
        case 1 : {
          switch (data[1]) {
            case 0 : {
              if (formattingInt(patches[2].data) == formattingInt(patches[3].data)) {
                patches[0].update(cell);
              } else {
                patches[1].update(cell);
              }
              break;
            }
            case 1 : {
              if (formattingInt(patches[2].data) < formattingInt(patches[3].data)) {
                patches[0].update(cell);
              } else {
                patches[1].update(cell);
              }
              break;
            }
            case 2 : {
              if (formattingInt(patches[2].data) > formattingInt(patches[3].data)) {
                patches[0].update(cell);
              } else {
                patches[1].update(cell);
              }
              break;
            }
            case 3 : {
              if (formattingInt(patches[2].data) != formattingInt(patches[3].data)) {
                patches[0].update(cell);
              } else {
                patches[1].update(cell);
              }
              break;
            }
            case 4 : {
              if (formattingInt(patches[2].data) <= formattingInt(patches[3].data)) {
                patches[0].update(cell);
              } else {
                patches[1].update(cell);
              }
              break;
            }
            case 5 : {
              if (formattingInt(patches[2].data) >= formattingInt(patches[3].data)) {
                patches[0].update(cell);
              } else {
                patches[1].update(cell);
              }
            }
          }
          break;
        }
        case 2 : {
          switch (data[1]) {
            case 0 : {
              if (Float.intBitsToFloat(formattingInt(patches[2].data)) == Float.intBitsToFloat(formattingInt(patches[3].data))) {
                patches[0].update(cell);
              } else {
                patches[1].update(cell);
              }
              break;
            }
            case 1 : {
              if (Float.intBitsToFloat(formattingInt(patches[2].data)) < Float.intBitsToFloat(formattingInt(patches[3].data))) {
                patches[0].update(cell);
              } else {
                patches[1].update(cell);
              }
              break;
            }
            case 2 : {
              if (Float.intBitsToFloat(formattingInt(patches[2].data)) > Float.intBitsToFloat(formattingInt(patches[3].data))) {
                patches[0].update(cell);
              } else {
                patches[1].update(cell);
              }
              break;
            }
            case 3 : {
              if (Float.intBitsToFloat(formattingInt(patches[2].data)) != Float.intBitsToFloat(formattingInt(patches[3].data))) {
                patches[0].update(cell);
              } else {
                patches[1].update(cell);
              }
              break;
            }
            case 4 : {
              if (Float.intBitsToFloat(formattingInt(patches[2].data)) <= Float.intBitsToFloat(formattingInt(patches[3].data))) {
                patches[0].update(cell);
              } else {
                patches[1].update(cell);
              }
              break;
            }
            case 5 : {
              if (Float.intBitsToFloat(formattingInt(patches[2].data)) >= Float.intBitsToFloat(formattingInt(patches[3].data))) {
                patches[0].update(cell);
              } else {
                patches[1].update(cell);
              }
            }
          }
          break;
        }
        case 4 : {
          switch (data[1]) {
            case 0 : {
              patches[1].data[0] = byte(patches[2].data[0]);
              break;
            }
            case 1 : {
              patches[1].data[0] = byte(patches[1].data[0] - patches[2].data[0]);
              break;
            }
            case 2 : {
              patches[1].data[0] = byte(patches[1].data[0] / patches[2].data[0]);
              break;
            }
            case 3 : {
              patches[1].data[0] = byte(patches[1].data[0] + patches[2].data[0]);
              break;
            }
            case 4 : {
              patches[1].data[0] = byte(patches[1].data[0] * patches[2].data[0]);
            }
          }
          patches[0].update(cell);
          break;
        }
        case 5 : {
          switch (data[1]) {
            case 0 : {
              patches[1].data = formattingByte(formattingInt(patches[2].data));
              break;
            }
            case 1 : {
              patches[1].data = formattingByte(formattingInt(patches[1].data) - formattingInt(patches[2].data));
              break;
            }
            case 2 : {
              patches[1].data = formattingByte(formattingInt(patches[1].data) / formattingInt(patches[2].data));
              break;
            }
            case 3 : {
              patches[1].data = formattingByte(formattingInt(patches[1].data) + formattingInt(patches[2].data));
              break;
            }
            case 4 : {
              patches[1].data = formattingByte(formattingInt(patches[1].data) * formattingInt(patches[2].data));
            }
          }
          patches[0].update(cell);
          break;
        }
        case 6 : {
          switch (data[1]) {
            case 0 : {
              patches[1].data = formattingByte(formattingInt(patches[2].data));
              break;
            }
            case 1 : {
              patches[1].data = formattingByte(Float.floatToIntBits(Float.intBitsToFloat(formattingInt(patches[1].data)) - Float.intBitsToFloat(formattingInt(patches[2].data))));
              break;
            }
            case 2 : {
              patches[1].data = formattingByte(Float.floatToIntBits(Float.intBitsToFloat(formattingInt(patches[1].data)) / Float.intBitsToFloat(formattingInt(patches[2].data))));
              break;
            }
            case 3 : {
              patches[1].data = formattingByte(Float.floatToIntBits(Float.intBitsToFloat(formattingInt(patches[1].data)) + Float.intBitsToFloat(formattingInt(patches[2].data))));
              break;
            }
            case 4 : {
              patches[1].data = formattingByte(Float.floatToIntBits(Float.intBitsToFloat(formattingInt(patches[1].data)) * Float.intBitsToFloat(formattingInt(patches[2].data))));
            }
          }
          patches[0].update(cell);
          break;
        }
        case 7 : {
          cell.logics.add(new Logic(patches[1].data.clone(), patches[1].patches.clone()));
          patches[0].update(cell);
          break;
        }
        case 8 : {
          cell.organelles.add(new Organelle(cell, patches[1].data[0], Float.intBitsToFloat(formattingInt(patches[2].data)), Float.intBitsToFloat(formattingInt(patches[3].data)), data[1] == 0 ? false : true));
          patches[0].update(cell);
          break;
        }
        case 9 : {
          cell.red = byte(patches[1].data[0]);
          patches[0].update(cell);
          break;
        }
        case 10 : {
          cell.green = byte(patches[1].data[0]);
          patches[0].update(cell);
          break;
        }
        case 11 : {
          cell.blue = byte(patches[1].data[0]);
          patches[0].update(cell);
          break;
        }
        case 12 : {
          float transfer = Float.intBitsToFloat(formattingInt(patches[1].data));
          if (patches[2].data[0] < cell.adjacent.size()) {
            transfer = min(transfer, cell.adjacent.get(patches[2].data[0]).cell.mass);
            cell.adjacent.get(patches[2].data[0]).cell.mass -= transfer;
            cell.adjacent.get(patches[2].data[0]).cell2.mass += transfer;
          }
          break;
        }
        case 13 : {
          cell.split = true;
          cell.splitAngle = Float.intBitsToFloat(formattingInt(patches[1].data));
          break;
        }
        case 14 : {
          cell.splitLinked = true;
          cell.splitAngle = Float.intBitsToFloat(formattingInt(patches[1].data));
          break;
        }
        case 15 : {
          patches[0].update(cell);
          break;
        }
        case 16 : {
          semiochemicals.add(new Semiochemical(cell, formattingInt(patches[1].data), Float.intBitsToFloat(formattingInt(patches[2].data)), Float.intBitsToFloat(formattingInt(patches[3].data))));
          patches[0].update(cell);
          break;
        }
        case 17 : {
          final int semiochemical = formattingInt(patches[1].data);
          patches[2].data = formattingByte(Float.floatToIntBits(semiochemical < cell.concentrations.size() ? cell.concentrations.get(semiochemical) : 0f));
          patches[0].update(cell);
          break;
        }
        case 18 : {
          cell.apoptosis();
          break;
        }
        case 20 : case 21 : {
          patches[0].update(cell);
        }
      }
    }
  }
  private final class Resetter {
    public final int pointer;
    public final byte[] data;
    Resetter(int pointer, byte[] data) {
      this.pointer = pointer;
      this.data = data;
    }
  }
  private Programm programm;
  private final class Programm {
    public Logic execute;
    public final ArrayList<Logic> system;
    public final ArrayList<Resetter> resetters, resetters2;
    Programm() {
      system = new ArrayList<Logic>();
      resetters = new ArrayList<Resetter>();
      resetters2 = new ArrayList<Resetter>();
    }
  }
  final Caller caller;
  private final class Caller {
    private Cell forceps;
    Caller() {
    }
    @SuppressWarnings("serial") public final void compilation() {
      final String source = interface2.source.getText().toString();
      String token = "";
      final ArrayList<String> tokens = new ArrayList<String>();
      final ArrayList<ArrayList<String>> commands = new ArrayList<ArrayList<String>>();
      for (final char character : source.toCharArray()) {
        if (character == ' ' || character == ';' || character == '{' || character == '}' || character == ']') {
          if (token.length() != 0) {
            tokens.add(token);
          }
          token = "";
          if (character == ';' || character == '{' || character == '}' || character == ']') {
            if (character == '}') {
              commands.add(new ArrayList<String>() {{add("}");}});
            } else {
              commands.add(new ArrayList<String>(tokens));
            }
            tokens.clear();
          }
        } else if (character != '\n') {
          token += character;
        }
      }
      final class Binder {
        public final String name;
        public final boolean fractional;
        public final Logic pointer;
        Binder(String name, boolean fractional, Logic pointer) {
          this.name = name;
          this.fractional = fractional;
          this.pointer = pointer;
        }
      }
      final ArrayList<Binder> binders = new ArrayList<Binder>();
      final ArrayList<Logic> compilate = new ArrayList<Logic>();
      programm = new Programm();
      final Logic mass = new Logic(new byte[4], new Logic[0]);
      programm.system.add(mass);
      binders.add(new Binder("MASS", true, mass));
      final Logic links = new Logic(new byte[1], new Logic[0]);
      programm.system.add(links);
      binders.add(new Binder("LINKS", true, links));
      programm.system.add(pi);
      binders.add(new Binder("PI", true, pi));
      String syntax = "no problems found";
      boolean radian = false, error = false;
      for (final ArrayList<String> command : commands) {
        if (!command.get(0).equals("[")) {
          if (command.get(0).equals("@radian")) {
            radian = true;
          } else if (command.get(0).equals("@float")) {
            radian = false;
          } else if (command.get(0).equals("byte")) {
            final Logic logic = new Logic(new byte[] {byte(int(command.get(2)))}, new Logic[0]);
            if (command.size() == 5 && command.get(3).equals("heirdom")) {
              if (command.get(4).equals("0")) {
                programm.resetters.add(new Resetter(programm.system.size(), logic.data));
              } else if (command.get(4).equals("1")) {
                programm.resetters2.add(new Resetter(programm.system.size(), logic.data));
              } else if (!command.get(4).equals("2")) {
                syntax = "the method \"heirdom\" needs number (0, 1 kr)\nat : " + command;
              }
            } else {
              programm.resetters.add(new Resetter(programm.system.size(), logic.data));
              programm.resetters2.add(new Resetter(programm.system.size(), logic.data));
            }
            programm.system.add(logic);
            binders.add(new Binder(command.get(1), false, logic));
          } else if (command.get(0).equals("int")) {
            final Logic logic = new Logic(formattingByte(int(command.get(2))), new Logic[0]);
            if (command.size() == 5 && command.get(3).equals("heirdom")) {
              if (command.get(4).equals("0")) {
                programm.resetters.add(new Resetter(programm.system.size(), logic.data));
              } else if (command.get(4).equals("1")) {
                programm.resetters2.add(new Resetter(programm.system.size(), logic.data));
              } else {
                syntax = "the method \"heirdom\" needs number (0, 1 or 2)\nat : " + command;
              }
            } else {
              programm.resetters.add(new Resetter(programm.system.size(), logic.data));
              programm.resetters2.add(new Resetter(programm.system.size(), logic.data));
            }
            programm.system.add(logic);
            binders.add(new Binder(command.get(1), false, logic));
          } else if (command.get(0).equals("float")) {
            final Logic logic = new Logic(formattingByte(Float.floatToRawIntBits(float(command.get(2)))), new Logic[0]);
            if (command.size() == 5 && command.get(3).equals("heirdom")) {
              if (command.get(4).equals("0")) {
                programm.resetters.add(new Resetter(programm.system.size(), logic.data));
              } else if (command.get(4).equals("1")) {
                programm.resetters2.add(new Resetter(programm.system.size(), logic.data));
              } else {
                syntax = "the method \"heirdom\" needs number (0, 1 or 2)\nat : " + command;
              }
            } else {
              programm.resetters.add(new Resetter(programm.system.size(), logic.data));
              programm.resetters2.add(new Resetter(programm.system.size(), logic.data));
            }
            programm.system.add(logic);
            binders.add(new Binder(command.get(1), true, logic));
          } else if (command.get(0).equals("if")) {
            byte type = -1;
            for (final Binder binder : binders) {
              if (binder.name.equals(command.get(1))) {
                type = byte(binder.pointer.data.length == 1 ? 0 : binder.fractional ? 2 : 1);
                break;
              }
            }
            if (type == -1) {
              for (final Binder binder : binders) {
                if (binder.name.equals(command.get(3))) {
                  type = byte(binder.pointer.data.length == 1 ? 0 : binder.fractional ? 2 : 1);
                  break;
                }
              }
            }
            if (type == -1) {
              type = 1;
            }
            Logic variable = new Logic(new byte[0], new Logic[0]), variable2 = new Logic(new byte[0], new Logic[0]);
            if (command.get(1).charAt(0) == '-' || command.get(1).charAt(0) >= '0' && command.get(1).charAt(0) <= '9') {
              if (type == 0) {
                variable = new Logic(new byte[] {byte(int(command.get(1)))}, new Logic[0]);
              } else if (type == 1) {
                variable = new Logic(formattingByte(int(command.get(1))), new Logic[0]);
              } else {
                variable = new Logic(formattingByte(Float.floatToRawIntBits(float(command.get(1)))), new Logic[0]);
              }
            } else {
              for (final Binder binder : binders) {
                if (binder.name.equals(command.get(1))) {
                  variable = binder.pointer;
                  break;
                }
              }
            }
            if (command.get(3).charAt(0) == '-' || command.get(3).charAt(0) >= '0' && command.get(3).charAt(0) <= '9') {
              if (type == 0) {
                variable2 = new Logic(new byte[] {byte(int(command.get(3)))}, new Logic[0]);
              } else if (type == 1) {
                variable2 = new Logic(formattingByte(int(command.get(3))), new Logic[0]);
              } else {
                variable2 = new Logic(formattingByte(Float.floatToRawIntBits(float(command.get(3)))), new Logic[0]);
              }
            } else {
              for (final Binder binder : binders) {
                if (binder.name.equals(command.get(3))) {
                  variable2 = binder.pointer;
                  break;
                }
              }
            }
            final Logic logic = new Logic(new byte[] {type, byte(command.get(2).equals("==") ? 0 : command.get(2).equals("<") ? 1 : command.get(2).equals(">") ? 2 : command.get(2).equals("!=") ? 3 : command.get(2).equals("<=") ? 4 : command.get(2).equals(">=") ? 5 : 6)}, new Logic[] {null, null, variable, variable2});
            programm.system.add(logic);
            compilate.add(logic);
          } else if (command.get(0).equals("load")) {
            final Logic logic = new Logic(new byte[] {19}, new Logic[1]);
            programm.system.add(logic);
            compilate.add(logic);
          } else if (command.get(0).equals("return")) {
            final Logic logic = new Logic(new byte[] {20}, new Logic[1]);
            programm.system.add(logic);
            compilate.add(logic);
          } else if (command.get(0).equals("}")) {
            final Logic logic = new Logic(new byte[] {15}, new Logic[1]);
            programm.system.add(logic);
            compilate.add(logic);
          } else if (command.get(0).equals("organelle")) {
            final Logic logic = new Logic(new byte[] {byte(radian ? -8 : 8), byte(command.get(4).equals("0") ? 0 : 1)}, new Logic[4]);
            if (command.get(1).charAt(0) == '-' || command.get(1).charAt(0) >= '0' && command.get(1).charAt(0) <= '9') {
              logic.patches[1] = new Logic(new byte[] {byte(int(command.get(1)))}, new Logic[0]);
            } else {
              for (final Binder binder : binders) {
                if (binder.name.equals(command.get(1))) {
                  logic.patches[1] = binder.pointer;
                  break;
                }
              }
            }
            if (command.get(2).charAt(0) == '-' || command.get(2).charAt(0) >= '0' && command.get(2).charAt(0) <= '9') {
              logic.patches[2] = new Logic(formattingByte(Float.floatToRawIntBits(float(command.get(2)))), new Logic[0]);
            } else {
              for (final Binder binder : binders) {
                if (binder.name.equals(command.get(2))) {
                  logic.patches[2] = binder.pointer;
                  break;
                }
              }
            }
            if (command.get(3).charAt(0) == '-' || command.get(3).charAt(0) >= '0' && command.get(3).charAt(0) <= '9') {
              final Logic logic2 = new Logic(formattingByte(Float.floatToRawIntBits(float(command.get(3)))), new Logic[0]);
              logic.patches[3] = logic2;
            } else {
              for (final Binder binder : binders) {
                if (binder.name.equals(command.get(3))) {
                  logic.patches[3] = binder.pointer;
                  break;
                }
              }
            }
            programm.system.add(logic);
            compilate.add(logic);
          } else if (command.get(0).equals("red")) {
            if (command.get(1).charAt(0) == '-' || command.get(1).charAt(0) >= '0' && command.get(1).charAt(0) <= '9') {
              final Logic logic = new Logic(new byte[] {9}, new Logic[] {null, new Logic(new byte[] {byte(int(command.get(1)))}, new Logic[0])});
              programm.system.add(logic);
              compilate.add(logic);
            } else {
              for (final Binder binder : binders) {
                if (binder.name.equals(command.get(1))) {
                  final Logic logic = new Logic(new byte[] {9}, new Logic[] {null, binder.pointer});
                  programm.system.add(logic);
                  compilate.add(logic);
                  break;
                }
              }
            }
          } else if (command.get(0).equals("green")) {
            if (command.get(1).charAt(0) == '-' || command.get(1).charAt(0) >= '0' && command.get(1).charAt(0) <= '9') {
              final Logic logic = new Logic(new byte[] {10}, new Logic[] {null, new Logic(new byte[] {byte(int(command.get(1)))}, new Logic[0])});
              programm.system.add(logic);
              compilate.add(logic);
            } else {
              for (final Binder binder : binders) {
                if (binder.name.equals(command.get(1))) {
                  final Logic logic = new Logic(new byte[] {10}, new Logic[] {null, binder.pointer});
                  programm.system.add(logic);
                  compilate.add(logic);
                  break;
                }
              }
            }
          } else if (command.get(0).equals("blue")) {
            if (command.get(1).charAt(0) == '-' || command.get(1).charAt(0) >= '0' && command.get(1).charAt(0) <= '9') {
              final Logic logic = new Logic(new byte[] {11}, new Logic[] {null, new Logic(new byte[] {byte(int(command.get(1)))}, new Logic[0])});
              programm.system.add(logic);
              compilate.add(logic);
            } else {
              for (final Binder binder : binders) {
                if (binder.name.equals(command.get(1))) {
                  final Logic logic = new Logic(new byte[] {11}, new Logic[] {null, binder.pointer});
                  programm.system.add(logic);
                  compilate.add(logic);
                  break;
                }
              }
            }
          } else if (command.get(0).equals("diffusion")) {
            final Logic logic = new Logic(new byte[] {16}, new Logic[4]);
            if (command.get(1).charAt(0) == '-' || command.get(1).charAt(0) >= '0' && command.get(1).charAt(0) <= '9') {
              logic.patches[1] = new Logic(formattingByte(int(command.get(1))), new Logic[0]);
            } else {
              for (final Binder binder : binders) {
                if (binder.name.equals(command.get(1))) {
                  logic.patches[1] = binder.pointer;
                  break;
                }
              }
            }
            if (command.get(2).charAt(0) == '-' || command.get(2).charAt(0) >= '0' && command.get(2).charAt(0) <= '9') {
              logic.patches[2] = new Logic(formattingByte(Float.floatToRawIntBits(float(command.get(2)))), new Logic[0]);
            } else {
              for (final Binder binder : binders) {
                if (binder.name.equals(command.get(2))) {
                  logic.patches[2] = binder.pointer;
                  break;
                }
              }
            }
            if (command.get(3).charAt(0) == '-' || command.get(3).charAt(0) >= '0' && command.get(3).charAt(0) <= '9') {
              logic.patches[3] = new Logic(formattingByte(Float.floatToRawIntBits(float(command.get(3)))), new Logic[0]);
            } else {
              for (final Binder binder : binders) {
                if (binder.name.equals(command.get(3))) {
                  logic.patches[3] = binder.pointer;
                  break;
                }
              }
            }
            programm.system.add(logic);
            compilate.add(logic);
          } else if (command.get(0).equals("detect")) {
            final Logic logic = new Logic(new byte[] {17}, new Logic[4]);
            if (command.get(1).charAt(0) == '-' || command.get(1).charAt(0) >= '0' && command.get(1).charAt(0) <= '9') {
              logic.patches[1] = new Logic(formattingByte(int(command.get(1))), new Logic[0]);
            } else {
              for (final Binder binder : binders) {
                if (binder.name.equals(command.get(1))) {
                  logic.patches[1] = binder.pointer;
                  break;
                }
              }
            }
            if (command.get(2).charAt(0) == '-' || command.get(2).charAt(0) >= '0' && command.get(2).charAt(0) <= '9') {
              logic.patches[2] = new Logic(formattingByte(int(command.get(2))), new Logic[0]);
            } else {
              for (final Binder binder : binders) {
                if (binder.name.equals(command.get(2))) {
                  logic.patches[2] = binder.pointer;
                  break;
                }
              }
            }
            programm.system.add(logic);
            compilate.add(logic);
          } else if (command.get(0).equals("transfer")) {
            final Logic logic = new Logic(new byte[] {12}, new Logic[3]);
            if (command.get(1).charAt(0) >= '0' && command.get(1).charAt(0) <= '9') {
              logic.patches[1] = new Logic(formattingByte(Float.floatToRawIntBits(float(command.get(1)))), new Logic[0]);
            } else if (command.get(1).charAt(0) == '-') {
              syntax = "the method \"transfer\" does not assume the use of negative numbers in the 2nd input\n" + error;
            } else {
              for (final Binder binder : binders) {
                if (binder.name.equals(command.get(1))) {
                  logic.patches[1] = binder.pointer;
                  break;
                }
              }
            }
            if (command.get(2).charAt(0) == '-' || command.get(2).charAt(0) >= '0' && command.get(2).charAt(0) <= '9') {
              logic.patches[2] = new Logic(new byte[] {byte(int(command.get(2)))}, new Logic[0]);
            } else {
              for (final Binder binder : binders) {
                if (binder.name.equals(command.get(2))) {
                  logic.patches[2] = binder.pointer;
                  break;
                }
              }
            }
            programm.system.add(logic);
            compilate.add(logic);
          } else if (command.get(0).equals("break")) {
            final Logic logic = new Logic(new byte[] {19}, new Logic[0]);
            programm.system.add(logic);
            compilate.add(logic);
          } else if (command.get(0).equals("split")) {
            final Logic logic = new Logic(new byte[] {byte(command.get(1).equals("0") && !command.get(1).equals("1") ? radian ? -13 : 13 : radian ? -14 : 14)}, new Logic[2]);
            if (command.get(2).charAt(0) == '-' || command.get(2).charAt(0) >= '0' && command.get(2).charAt(0) <= '9') {
              logic.patches[1] = new Logic(formattingByte(Float.floatToRawIntBits(float(command.get(2)))), new Logic[0]);
            } else {
              for (final Binder binder : binders) {
                if (binder.name.equals(command.get(2))) {
                  logic.patches[1] = binder.pointer;
                  break;
                }
              }
            }
            programm.system.add(logic);
            compilate.add(logic);
          } else if (command.get(0).equals("apoptosis")) {
            final Logic logic = new Logic(new byte[] {18}, new Logic[0]);
            programm.system.add(logic);
            compilate.add(logic);
          } else {
            for (final Binder binder : binders) {
              if (binder.name.equals(command.get(0))) {
                if (binder.pointer.data.length == 1) {
                  if (command.get(1).charAt(0) == '-' || command.get(1).charAt(0) >= '0' && command.get(1).charAt(0) <= '9') {
                    final Logic constant = new Logic(new byte[] {byte(int(command.get(1)))}, new Logic[0]), formula = new Logic(new byte[] {4, 0}, new Logic[] {null, binder.pointer, constant});
                    programm.system.add(formula);
                    compilate.add(formula);
                  } else {
                    for (final Binder binder2 : binders) {
                      if (binder2.name.equals(command.get(1))) {
                        final Logic formula = new Logic(new byte[] {4, 0}, new Logic[] {null, binder.pointer, binder2.pointer});
                        programm.system.add(formula);
                        compilate.add(formula);
                        break;
                      }
                    }
                  }
                  for (int formula = 2; formula + 1 < command.size(); formula += 2) {
                    final Logic operator = new Logic(new byte[] {4, byte(command.get(formula).equals("-") ? 1 : command.get(formula).equals("/") ? 2 : command.get(formula).equals("+") ? 3 : command.get(formula).equals("*") ? 4 : 5)}, null);
                    final int formula2 = formula + 1;
                    if (command.get(formula2).charAt(0) == '-' || command.get(formula2).charAt(0) >= '0' && command.get(formula2).charAt(0) <= '9') {
                      final Logic constant = new Logic(new byte[] {byte(int(command.get(formula2)))}, new Logic[0]);
                      operator.patches = new Logic[] {null, binder.pointer, constant};
                      programm.system.add(operator);
                      compilate.add(operator);
                    } else {
                      for (final Binder binder2 : binders) {
                        if (binder2.name.equals(command.get(formula2))) {
                          operator.patches = new Logic[] {null, binder.pointer, binder2.pointer};
                          programm.system.add(operator);
                          compilate.add(operator);
                          break;
                        }
                      }
                    }
                  }
                } else {
                  if (binder.fractional) {
                    if (command.get(1).charAt(0) == '-' || command.get(1).charAt(0) >= '0' && command.get(1).charAt(0) <= '9') {
                      final Logic constant = new Logic(formattingByte(Float.floatToRawIntBits(float(command.get(1)))), new Logic[0]), formula = new Logic(new byte[] {6, 0}, new Logic[] {null, binder.pointer, constant});
                      programm.system.add(formula);
                      compilate.add(formula);
                    } else {
                      for (final Binder binder2 : binders) {
                        if (binder2.name.equals(command.get(1))) {
                          final Logic formula = new Logic(new byte[] {6, 0}, new Logic[] {null, binder.pointer, binder2.pointer});
                          programm.system.add(formula);
                          compilate.add(formula);
                          break;
                        }
                      }
                    }
                    for (int formula = 2; formula + 1 < command.size(); formula += 2) {
                      final Logic operator = new Logic(new byte[] {6, byte(command.get(formula).equals("-") ? 1 : command.get(formula).equals("/") ? 2 : command.get(formula).equals("+") ? 3 : command.get(formula).equals("*") ? 4 : 5)}, null);
                      final int formula2 = formula + 1;
                      if (command.get(formula2).charAt(0) == '-' || command.get(formula2).charAt(0) >= '0' && command.get(formula2).charAt(0) <= '9') {
                        final Logic constant = new Logic(formattingByte(Float.floatToRawIntBits(float(command.get(formula2)))), new Logic[0]);
                        operator.patches = new Logic[] {null, binder.pointer, constant};
                        programm.system.add(operator);
                        compilate.add(operator);
                      } else {
                        for (final Binder binder2 : binders) {
                          if (binder2.name.equals(command.get(formula2))) {
                            operator.patches = new Logic[] {null, binder.pointer, binder2.pointer};
                            programm.system.add(operator);
                            compilate.add(operator);
                            break;
                          }
                        }
                      }
                    }
                  } else {
                    boolean lost = true;
                    if (command.get(1).charAt(0) == '-' || command.get(1).charAt(0) >= '0' && command.get(1).charAt(0) <= '9') {
                      final Logic constant = new Logic(formattingByte(int(command.get(1))), new Logic[0]), formula = new Logic(new byte[] {5, 0}, new Logic[] {null, binder.pointer, constant});
                      programm.system.add(formula);
                      compilate.add(formula);
                    } else {
                      for (final Binder binder2 : binders) {
                        if (binder2.name.equals(command.get(1))) {
                          final Logic formula = new Logic(new byte[] {5, 0}, new Logic[] {null, binder.pointer, binder2.pointer});
                          programm.system.add(formula);
                          compilate.add(formula);
                          lost = false;
                          break;
                        }
                      }
                    }
                    for (int formula = 2; formula + 1 < command.size(); formula += 2) {
                      final Logic operator = new Logic(new byte[] {5, byte(command.get(formula).equals("-") ? 1 : command.get(formula).equals("/") ? 2 : command.get(formula).equals("+") ? 3 : command.get(formula).equals("*") ? 4 : 5)}, null);
                      final int formula2 = formula + 1;
                      if (command.get(formula2).charAt(0) == '-' || command.get(formula2).charAt(0) >= '0' && command.get(formula2).charAt(0) <= '9') {
                        final Logic constant = new Logic(formattingByte(int(command.get(formula2))), new Logic[0]);
                        operator.patches = new Logic[] {null, binder.pointer, constant};
                        programm.system.add(operator);
                        compilate.add(operator);
                      } else { 
                        for (final Binder binder2 : binders) {
                          if (binder2.name.equals(command.get(formula2))) {
                            operator.patches = new Logic[] {null, binder.pointer, binder2.pointer};
                            programm.system.add(operator);
                            compilate.add(operator);
                            lost = false;
                            break;
                          }
                        }
                      }
                    }
                    if (lost) {
                      syntax = "syntax error\nvariable at \"" + command + "\" not found";
                    }
                  }
                }
                break;
              }
            }
          }
        }
      }
      try {
        programm.execute = compilate.get(0);
        final ArrayList<Logic> union = new ArrayList<Logic>(), cycle = new ArrayList<Logic>();
        for (int logic = 0; logic < compilate.size(); logic++) {
          if (compilate.get(logic).data[0] < 18) {
            compilate.get(logic).patches[0] = compilate.get(logic + 1);
            if (compilate.get(logic).data[0] > -8 && compilate.get(logic).data[0] < 3) {
              union.add(compilate.get(logic));
            } else if (compilate.get(logic).data[0] == 15) {
              final int space = union.size() - 1;
              union.get(space).patches[1] = compilate.get(logic + 1);
              union.remove(space);
            }
          } else if (compilate.get(logic).data[0] == 20) {
            compilate.get(logic).patches[0] = compilate.get(logic + 1);
            cycle.add(compilate.get(logic));
          } else if (compilate.get(logic).data[0] == 21) {
            final int space = cycle.size() - 1;
            compilate.get(logic).patches[0] = cycle.get(space).patches[0];
            cycle.remove(space);
          }
        }
        interface2.returns(error, error ? "syntax error\n" + syntax : syntax);
      } catch (Exception log) {
        interface2.returns(true, "patches error\n" + log.toString());
      }
    }
    private float offsetX, offsetY;
    public final void update(byte mode, TouchEvent.Pointer touch) {
      switch (mode) {
        case 0 : {
          final float touchX = touch.x / microscopeScale + microscopeX, touchY = touch.y / microscopeScale + microscopeY;
          if (click) {
            offsetX = touchX;
            offsetY = touchY;
            click = false;
          }
          microscopeX += offsetX - touchX;
          microscopeY += offsetY - touchY;
          break;
        }
        case 1 : {
          final float touchX = touch.x / microscopeScale + microscopeX, touchY = touch.y / microscopeScale + microscopeY;
          for (final Cell cell : cells) {
            if (dist(cell.positionX, cell.positionY, touchX, touchY) < 1) {
              forceps = cell;
              break;
            }
          }
          if (forceps != null) {
            forceps.positionX = touchX;
            forceps.positionY = touchY;
          }
          break;
        }
        case 2 : {
          cells.add(new Cell(programm.execute, programm.system, 0, 0, 0, 0, touch.x / microscopeScale + microscopeX, touch.y / microscopeScale + microscopeY, 10, byte(random(255)), byte(random(255)), byte(random(255)), programm.resetters, programm.resetters2, false));
          break;
        }
        case 3 : {
          for (final Cell cell : cells) {
            if (dist(cell.positionX, cell.positionY, touch.x / microscopeScale + microscopeX, touch.y / microscopeScale + microscopeY) < 1) {
              cell.apoptosis();
              break;
            }
          }
        }
        case 6 : {
          compilation();
        }
      }
    }
    public final void cleanUp() {
      organics.clear();
      semiochemicals.clear();
      for (final Cell cell : cells) {
        cell.apoptosis();
      }
      while (organics.size() < 1000) {
        final float angle = random(TWO_PI), radius = sqrt(random(900));
        organics.add(new Organic(sin(angle) * radius + 60, cos(angle) * radius + 60));
      }
    }
    public final void zoom(float distance) {
      microscopeScale += distance * microscopeScale;
    }
  }
  private final ArrayList<Space> spacesUsing;
  private final Space[][] spaces;
  private final class Space {
    public final int positionX, positionY;
    public final java.util.IdentityHashMap<Organic, Boolean> organicsUsing;
    public final java.util.IdentityHashMap<Cell, Boolean> cellsUsing;
    public final ArrayList<Organic> organics;
    public ArrayList<Cell> cellsUpdate;
    public final ArrayList<Cell> cells;
    Space(int positionX, int positionY) {
      this.positionX = positionX;
      this.positionY = positionY;
      organicsUsing = new java.util.IdentityHashMap<Organic, Boolean>();
      organics = new ArrayList<Organic>();
      cellsUsing = new java.util.IdentityHashMap<Cell, Boolean>();
      cells = new ArrayList<Cell>();
      cellsUpdate = new ArrayList<Cell>();
    }
    public final void update() {
      for (int cell = 0; cell < cells.size(); cell++) {
        for (int cell2 = 0; cell2 < cells.size(); cell2++) {
          if (cell != cell2 && abs(cells.get(cell).positionX - cells.get(cell2).positionX) < 1 && abs(cells.get(cell).positionY - cells.get(cell2).positionY) < 1) {
            final float distance = sq(dist(cells.get(cell).positionX, cells.get(cell).positionY, cells.get(cell2).positionX, cells.get(cell2).positionY) + 1) * 30;
            if (distance < 120 && int((cells.get(cell).positionX + cells.get(cell2).positionX) / 8) == positionX && int((cells.get(cell).positionY + cells.get(cell2).positionY) / 8) == positionY) {
              cellsUpdate.get(cell).angleVelocity += atan2(cells.get(cell).velocityX + cells.get(cell2).velocityX, cells.get(cell).velocityY + cells.get(cell2).velocityY) / distance;
              final float mass = (cells.get(cell2).mass - cells.get(cell).mass) / 10 + 1;
              cellsUpdate.get(cell).velocityX += (cells.get(cell).positionX - cells.get(cell2).positionX) / distance * mass;
              cellsUpdate.get(cell).velocityY += (cells.get(cell).positionY - cells.get(cell2).positionY) / distance * mass;
              if (distance < 80 && cells.get(cell).splited == 100) {
                if (cellsUpdate.get(cell).mass > cellsUpdate.get(cell2).mass) {
                  cellsUpdate.get(cell2).apoptosis();
                } else {
                  cellsUpdate.get(cell).apoptosis();
                }
              }
            }
          }
        }
        for (final Organic organic : organics) {
          cellsUpdate.get(cell).organics.add(organic);
        }
      }
      organics.clear();
      cells.clear();
      organicsUsing.clear();
      cellsUsing.clear();
    }
  }
  private float microscopeX, microscopeY;
  public float microscopeScale;
  private final PShader semiochemicalsPolygons;
  private final ArrayList<Semiochemical> semiochemicals, semiochemicalsRemoved;
  private final class Semiochemical {
    private final Cell source;
    public final int molecule;
    private final float radius, radius2, diffusion;
    private float concentration;
    Semiochemical(Cell source, int molecule, float radius, float diffusion) {
      this.source = source;
      this.molecule = molecule;
      this.radius = radius;
      radius2 = radius * 2;
      this.diffusion = diffusion;
      concentration = 1;
    }
    public final void update() {
      if (concentration > 0) {
        for (float x = -radius; x < radius; x++) {
          for (float y = -radius; y < radius; y++) {
            final int spaceX = int(x + source.positionX / 4), spaceY = int(y + source.positionY / 4);
            if (spaceX >= 0 && spaceX < spaces.length && spaceY >= 0 && spaceY < spaces[spaceX].length) {
              for (final Cell cell : spaces[spaceX][spaceY].cellsUpdate) {
                if (cell != source) {
                  final float distance = dist(cell.positionX, cell.positionY, source.positionX, source.positionY);
                  if (distance < radius2) {
                    if (molecule < cell.concentrations.size()) {
                      cell.concentrations.set(molecule, radius / (distance + 1));
                    } else {
                      for (int concentration = cell.concentrations.size(); concentration < molecule; concentration++) {
                        cell.concentrations.add(0f);
                      }
                      cell.concentrations.add(radius / (distance + 1));
                    }
                  }
                }
              }
            }
          }
        }
        concentration -= diffusion;
      } else {
        semiochemicalsRemoved.add(this);
      }
    }
    public final void render() {
      fill(source.red & 0xFF, source.green & 0xFF, source.blue & 0xFF, concentration * 255);
      final float coordinatesX = (source.positionX - microscopeX) * microscopeScale, coordinatesY = (source.positionY - microscopeY) * microscopeScale, resolution = 1.1547005 * microscopeScale * radius2, microscopeScaleDouble = microscopeScale * 2 * radius2;
      vertex(coordinatesX - resolution, coordinatesY - microscopeScaleDouble, -0.5773502692, -1);
      vertex(coordinatesX - resolution, coordinatesY + microscopeScaleDouble, -0.5773502692, 1);
      vertex(coordinatesX + 2.309401 * microscopeScale * radius2, coordinatesY, 1.1547005, 0);
    }
  }
  private final PShader organicsPolygons;
  private final ArrayList<Organic> organicsRemoved, organics;
  private final class Organic {
    float positionX, positionY;
    final byte red, green, blue;
    Organic(float positionX, float positionY) {
      this.positionX = positionX;
      this.positionY = positionY;
      red = byte(noise(positionX, positionY) * 400);
      green = byte(noise(positionY, positionX) * 200);
      blue = byte(noise(-positionX, positionY) * 100);
    }
    public final void update() {
      for (float x = positionX - 0.5; x < positionX + 0.6; x += 0.5) {
        for (float y = positionY - 0.5; y < positionY + 0.6; y += 0.5) {
          final int roundedX = int(x / 4), roundedY = int(y / 4);
          final Space space = spaces[roundedX][roundedY];
          spacesUsing.add(space);
          if (!space.cellsUsing.containsKey(this)) {
            space.organicsUsing.put(this, false);
            space.organics.add(this);
          }
          space.cellsUpdate = new ArrayList<Cell>(space.cells);
        }
      }
      fill(red & 0xFF, green & 0xFF, blue & 0xFF);
      final float coordinatesX = (positionX - microscopeX) * microscopeScale, coordinatesY = (positionY - microscopeY) * microscopeScale, resolution = 1.1547005 * microscopeScale, microscopeScaleDouble = microscopeScale * 2;
      vertex(coordinatesX - resolution, coordinatesY - microscopeScaleDouble, -0.5773502692, -1);
      vertex(coordinatesX - resolution, coordinatesY + microscopeScaleDouble, -0.5773502692, 1);
      vertex(coordinatesX + 2.309401 * microscopeScale, coordinatesY, 1.1547005, 0);
    }
  }
  private final PShader linksPolygons;
  private final ArrayList<Link> linksRemoved, links;
  private final class Link {
    public Cell cell, cell2;
    private byte red, green, blue;
    Link(Cell cell, Cell cell2) {
      this.cell = cell;
      this.cell2 = cell2;
      cell.adjacent.add(this);
      cell2.adjacent.add(this);
    }
    public final void apoptosis() {
      linksRemoved.add(this);
      particles.add(new Particle((cell.velocityX + cell2.velocityX) / 2, (cell.velocityY + cell2.velocityY) / 2, (cell.positionX + cell2.positionX) / 2, (cell.positionY + cell2.positionY) / 2, byte(red & 0xFF), byte(green & 0xFF), byte(blue & 0xFF)));
    }
    public final void update() {
      final float distance = sq(dist(cell.positionX, cell.positionY, cell2.positionX, cell2.positionY) - 1) * 0.05;
      red = byte(((cell.red & 0xFF) + (cell2.red & 0xFF)) / 2);
      green = byte(((cell.green & 0xFF) + (cell2.green & 0xFF)) / 2);
      blue = byte(((cell.blue & 0xFF) + (cell2.blue & 0xFF)) / 2);
      if (distance > 0.5) {
        apoptosis();
      } else {
        final float averageX = cell.positionX - cell2.positionX, averageY = cell.positionY - cell2.positionY, rotate = atan2(averageX, averageY);
        if (distance > 0) {
          final float pullsX = averageX * distance, pullsY = averageY * distance;
          cell.angle = rotate;
          cell.stretchingX -= pullsX;
          cell.stretchingY -= pullsY;
          cell2.angle = rotate;
          cell2.stretchingX += pullsX;
          cell2.stretchingY += pullsY;
        }
        fill(red & 0xFF, green & 0xFF, blue & 0xFF);
        final float sin = sin(-rotate) / 2, cos = cos(-rotate) / 2;
        vertex((cell.positionX - cos - microscopeX) * microscopeScale, (cell.positionY - sin - microscopeY) * microscopeScale, 0, PI);
        vertex((cell2.positionX - cos - microscopeX) * microscopeScale, (cell2.positionY - sin - microscopeY) * microscopeScale, 0, 0);
        vertex((cell2.positionX + cos - microscopeX) * microscopeScale, (cell2.positionY + sin - microscopeY) * microscopeScale, PI, 0);
        vertex((cell.positionX + cos - microscopeX) * microscopeScale, (cell.positionY + sin - microscopeY) * microscopeScale, PI, PI);
      }
    }
  }
  private final PShader cellsPolygons;
  private final Sound splitSound;
  private final ArrayList<Cell> cellsAdded, cellsRemoved;
  private ArrayList<Cell> cellsUpdate, cells;
  private final class Cell {
    public final ArrayList<Float> concentrations;
    private final ArrayList<Logic> logics;
    public boolean split, splitLinked;
    private byte constructor;
    public float splitAngle, angleVelocity, angle, velocityX, velocityY, stretchingX, stretchingY, positionX, positionY, mass;
    public final ArrayList<Organic> organics;
    public final ArrayList<Organelle> organelles;
    private final Logic execute;
    public byte splited, red, green, blue;
    public final ArrayList<Link> adjacent;
    private final Logic split(Logic logic, java.util.IdentityHashMap<Logic, Logic> links) {
      if (logic == null) {
        return null;
      }
      Logic added = links.get(logic);
      if (added != null) {
        return added;
      }
      added = new Logic(logic.data.clone(), new Logic[logic.patches.length]);
      links.put(logic, added);
      for (int patch = 0; patch < logic.patches.length; patch++) {
        added.patches[patch] = split(logic.patches[patch], links);
      }
      return added;
    }
    public final ArrayList<Resetter> resetters, resetters2;
    Cell(Logic execute, ArrayList<Logic> logics, float angleVelocity, float angle, float velocityX, float velocityY, float positionX, float positionY, float mass, byte red, byte green, byte blue, ArrayList<Resetter> resetters, ArrayList<Resetter> resetters2, boolean side) {
      concentrations = new ArrayList<Float>();
      final java.util.IdentityHashMap<Logic, Logic> logicsLinks = new java.util.IdentityHashMap<Logic, Logic>();
      final ArrayList<Logic> logicsAdded = new ArrayList<Logic>();
      for (final Logic logic : logics) {
        logicsAdded.add(split(logic, logicsLinks));
      }
      this.logics = logicsAdded;
      this.execute = split(execute, logicsLinks);
      organics = new ArrayList<Organic>();
      organelles = new ArrayList<Organelle>();
      this.angleVelocity = angleVelocity;
      this.angle = angle;
      this.velocityX = velocityX;
      this.velocityY = velocityY;
      this.positionX = positionX;
      this.positionY = positionY;
      this.mass = mass;
      this.red = red;
      this.green = green;
      this.blue = blue;
      this.resetters = new ArrayList<Resetter>();
      for (Resetter resetter : resetters) {
        this.resetters.add(new Resetter(resetter.pointer, resetter.data.clone()));
        if (side) {
          this.logics.get(resetter.pointer).data = resetter.data.clone();
        }
      }
      this.resetters2 = new ArrayList<Resetter>();
      for (Resetter resetter : resetters2) {
        this.resetters2.add(new Resetter(resetter.pointer, resetter.data.clone()));
        if (!side) {
          this.logics.get(resetter.pointer).data = resetter.data.clone();
        }
      }
      adjacent = new ArrayList<Link>();
    }
    public final void apoptosis() {
      cellsRemoved.add(this);
      for (final Link link : adjacent) {
        link.apoptosis();
      }
      particles.add(new Particle(velocityX, velocityY, positionX, positionY, red, green, blue));
    }
    public final void update() {
      if (mass > 0) {
        if (split) {
          if (constructor == 50) {
            final float side = splitAngle + angle, sin = sin(side) / 20, cos = cos(side) / 20, mass2 = mass / 2;
            cellsAdded.add(new Cell(execute, logics, angleVelocity, angle, velocityX - sin, velocityY - cos, positionX, positionY, mass2, red, green, blue, resetters, resetters2, false));
            cellsAdded.add(new Cell(execute, logics, angleVelocity, angle, velocityX + sin, velocityY + cos, positionX, positionY, mass2, red, green, blue, resetters, resetters2, true));
            apoptosis();
          } else {
            constructor++;
          }
          splitSound.play(1 / dist(positionX, positionY, microscopeX, microscopeY));
        } else if (splitLinked) {
          if (constructor == 50) {
            final float side = splitAngle + angle, sin = sin(side) / 20, cos = cos(side) / 20, mass2 = mass / 2;
            final Cell added = new Cell(execute, logics, angleVelocity, angle, velocityX - sin, velocityY - cos, positionX, positionY, mass2, red, green, blue, resetters, resetters2, false), added2 = new Cell(execute, logics, angleVelocity, angle, velocityX + sin, velocityY + cos, positionX, positionY, mass2, red, green, blue, resetters, resetters2, true);
            cellsAdded.add(added);
            cellsAdded.add(added2);
            links.add(new Link(added, added2));
            for (final Link link : adjacent) {
              if (link.cell == this) {
                link.cell = added;
              } else {
                link.cell2 = added;
              }
              added.adjacent.add(link);
            }
            cellsRemoved.add(this);
          } else {
            constructor++;
          }
          splitSound.play(1 / dist(positionX, positionY, microscopeX, microscopeY));
        } else {
          logics.get(0).data = formattingByte(Float.floatToRawIntBits(mass));
          logics.get(1).data[0] = byte(links.size());
          execute.update(this);
        }
        for (final Organelle organelle : organelles) {
          organelle.update();
        }
        angle += angleVelocity;
        angleVelocity *= 0.98;
        positionX += velocityX + stretchingX;
        positionY += velocityY + stretchingY;
        velocityX *= 0.98;
        velocityY *= 0.98;
        stretchingX *= 0.7;
        stretchingY *= 0.7;
        final float distance = dist(positionX, positionY, 60, 60);
        if (distance > 29.5) {
          final float velocity = -abs(velocityX) - abs(velocityY), angle = atan2(positionX - 60, positionY - 60), sin = sin(angle), cos = cos(angle);
          angleVelocity -= atan2(velocityX * positionX, velocityY * positionY) * velocity;
          velocityX = sin * velocity;
          velocityY = cos * velocity;
          positionX = sin * 29.5 + 60;
          positionY = cos * 29.5 + 60;
        }
        for (float x = positionX - 0.5; x < positionX + 0.6; x += 0.5) {
          for (float y = positionY - 0.5; y < positionY + 0.6; y += 0.5) {
            final int roundedX = int(x / 4), roundedY = int(y / 4);
            final Space space = spaces[roundedX][roundedY];
            spacesUsing.add(space);
            if (!space.cellsUsing.containsKey(this)) {
              space.cellsUsing.put(this, false);
              space.cells.add(this);
            }
            space.cellsUpdate = new ArrayList<Cell>(space.cells);
          }
        }
        fill(red & 0xFF, green & 0xFF, blue & 0xFF);
        normal(mass, 0, 0);
        final float coordinatesX = (positionX - microscopeX) * microscopeScale, coordinatesY = (positionY - microscopeY) * microscopeScale, resolution = 0.5773502692 * microscopeScale;
        vertex(coordinatesX - resolution, coordinatesY - microscopeScale, -0.5773502692, -1);
        vertex(coordinatesX - resolution, coordinatesY + microscopeScale, -0.5773502692, 1);
        vertex(coordinatesX + 1.1547005 * microscopeScale, coordinatesY, 1.1547005, 0);
        for (final Organelle organelle : organelles) {
          organellesRender.add(organelle);
        }
        if (splited != 100) {
          splited++;
        }
        if (mass > 10) {
          mass = 10;
        }
        for (int concentration = 0; concentration < concentrations.size(); concentration++) {
          concentrations.set(concentration, concentrations.get(concentration) * 0.9);
        }
        organics.clear();
      } else {
        apoptosis();
      }
    }
  }
  private final PShader particlesPolygons;
  private final ArrayList<Particle> particlesRemoved, particles;
  private final class Particle {
    private float velocityX, velocityY, positionX, positionY;
    private byte time, red, green, blue;
    Particle(float velocityX, float velocityY, float positionX, float positionY, byte red, byte green, byte blue) {
      this.velocityX = velocityX;
      this.velocityY = velocityY;
      this.positionX = positionX;
      this.positionY = positionY;
      time = 127;
      this.red = red;
      this.green = green;
      this.blue = blue;
    }
    public final void update() {
      if (time == -1) {
        particlesRemoved.add(this);
      } else {
        positionX += velocityX;
        positionY += velocityY;
        velocityX *= 0.98;
        velocityY *= 0.98;
        fill(red & 0xFF, green & 0xFF, blue & 0xFF, time);
        final float coordinatesX = (positionX - microscopeX) * microscopeScale, coordinatesY = (positionY - microscopeY) * microscopeScale, resolution = 1.1547005 * microscopeScale, microscopeScaleDouble = microscopeScale * 2;
        vertex(coordinatesX - resolution, coordinatesY - microscopeScaleDouble, -0.5773502692, -1);
        vertex(coordinatesX - resolution, coordinatesY + microscopeScaleDouble, -0.5773502692, 1);
        vertex(coordinatesX + 2.309401 * microscopeScale, coordinatesY, 1.1547005, 0);
        time -= 4;
      }
    }
  }
  Scene() {
    background = loadShader("background.fragment", "background.vertex");
    pi = new Logic(formattingByte(Float.floatToRawIntBits(PI)), new Logic[0]);
    caller = new Caller();
    caller.compilation();
    spacesUsing = new ArrayList<Space>();
    spaces = new Space[30][30];
    for (int x = 0; x < spaces.length; x++) {
      for (int y = 0; y < spaces[x].length; y++) {
        spaces[x][y] = new Space(x, y);
      }
    }
    semiochemicalsRemoved = new ArrayList<Semiochemical>();
    microscopeX = 15;
    microscopeY = 15;
    microscopeScale = 30;
    semiochemicalsPolygons = loadShader("semiochemicals.fragment", "semiochemicals.vertex");
    semiochemicals = new ArrayList<Semiochemical>();
    organicsRemoved = new ArrayList<Organic>();
    organicsPolygons = loadShader("organics.fragment", "organics.vertex");
    organics = new ArrayList<Organic>();
    while (organics.size() < 1000) {
      final float angle = random(TWO_PI), radius = sqrt(random(900));
      organics.add(new Organic(sin(angle) * radius + 60, cos(angle) * radius + 60));
    }
    linksRemoved = new ArrayList<Link>();
    linksPolygons = loadShader("links.fragment", "links.vertex");
    links = new ArrayList<Link>();
    cellsPolygons = loadShader("cells.fragment", "cells.vertex");
    noStroke();
    textureMode(NORMAL);
    splitSound = new Sound("split.wav");
    cellsAdded = new ArrayList<Cell>();
    cellsRemoved = new ArrayList<Cell>();
    cells = new ArrayList<Cell>();
    organellesPolygons = loadShader("organelles.fragment", "organelles.vertex");
    organellesRender = new ArrayList<Organelle>();
    particlesRemoved = new ArrayList<Particle>();
    particlesPolygons = loadShader("particles.fragment", "particles.vertex");
    particles = new ArrayList<Particle>();
  }
  public final void update() {
    final float right = width / microscopeScale + microscopeX, bottom = height / microscopeScale + microscopeY;
    background.set("scale", microscopeScale);
    shader(background);
    beginShape();
    vertex(0, 0, microscopeX, microscopeY);
    vertex(width, 0, right, microscopeY);
    vertex(width, height, right, bottom);
    vertex(0, height, microscopeX, bottom);
    endShape();
    for (final Semiochemical semiochemical : semiochemicals) {
      semiochemical.update();
    }
    shader(organicsPolygons);
    beginShape(TRIANGLES);
    for (final Organic organic : organics) {
      organic.update();
    }
    endShape();
    shader(linksPolygons);
    beginShape(QUAD);
    for (final Link link : links) {
      link.update();
    }
    endShape();
    cellsUpdate = new ArrayList<Cell>(cells);
    shader(cellsPolygons);
    beginShape(TRIANGLES);
    for (final Cell cell : cells) {
      cell.update();
    }
    endShape();
    shader(organellesPolygons);
    beginShape(TRIANGLES);
    for (final Organelle organelle : organellesRender) {
      organelle.render();
    }
    endShape();
    for (final Space space : spacesUsing) {
      space.update();
    }
    spacesUsing.clear();
    links.removeAll(linksRemoved);
    linksRemoved.clear();
    cells = new ArrayList<Cell>(cellsUpdate);
    cells.addAll(cellsAdded);
    cellsAdded.clear();
    if (organics.size() < 1000 && frameCount % (organics.size() + 1) == 0) {
      final float angle = random(TWO_PI), radius = sqrt(random(900));
      organics.add(new Organic(sin(angle) * radius + 60, cos(angle) * radius + 60));
    }
    shader(particlesPolygons);
    beginShape(TRIANGLES);
    for (final Particle particle : particles) {
      particle.update();
    }
    endShape();
    semiochemicals.removeAll(semiochemicalsRemoved);
    semiochemicalsRemoved.clear();
    shader(semiochemicalsPolygons);
    beginShape(TRIANGLES);
    for (final Semiochemical semiochemical : semiochemicals) {
      semiochemical.render();
    }
    endShape();
    resetShader();
    organics.removeAll(organicsRemoved);
    cells.removeAll(cellsRemoved);
    particles.removeAll(particlesRemoved);
    cellsRemoved.clear();
    organicsRemoved.clear();
    particlesRemoved.clear();
    organellesRender.clear();
    if (DEBUG && click) {
      println("\nfps " + frameRate + "\nmemory " + Debug.getNativeHeapAllocatedSize() * 1.0 / Runtime.getRuntime().totalMemory() + "\ntime " + millis() / 1000.0 + "\ncells " + scene.cells.size());
    }
    if (MASS) {
      for (final Cell cell : cells) {
        cell.mass = 10;
      }
    }
  }
}