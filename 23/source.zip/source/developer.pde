final boolean
DEBUG = true,
MASS = false;